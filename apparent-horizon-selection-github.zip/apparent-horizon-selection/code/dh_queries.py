"""Query count of quantum minimum finding (Durr-Hoyer with the BBHT exponential schedule, lambda=6/5) for M candidates,
simulated exactly from the success probabilities sin^2((2j+1)theta). Each round costs j oracle calls plus one to check
the measured candidate. Output: mean and 90% quantile of the total query count in units of sqrt(M)."""
import numpy as np, json
rng = np.random.default_rng(0)
def bbht(M, t, lam=6 / 5):
    th = np.arcsin(np.sqrt(t / M)); m = 1.0; q = 0
    while True:
        j = int(rng.integers(0, int(np.ceil(m)))); q += j + 1
        if rng.random() < np.sin((2 * j + 1) * th) ** 2: return q
        m = min(lam * m, np.sqrt(M))
def dh(M):
    r = int(rng.integers(0, M)); q = 0                  # rank of the current threshold, 0 = minimum
    while r > 0:
        q += bbht(M, r); r = int(rng.integers(0, r))     # the outcome is uniform over the r better candidates
    return q
out = {}
for M in (256, 512, 2 ** 10, 2 ** 14, 2 ** 18, 2 ** 22, 2 ** 26):
    Q = np.array([dh(M) for _ in range(2000)])
    out[M] = dict(mean=float(Q.mean()), c_mean=float(Q.mean() / np.sqrt(M)), c_q90=float(np.quantile(Q, 0.9) / np.sqrt(M)),
                  c_bound=float((22.5 * np.sqrt(M) + 1.4 * np.log2(M) ** 2) / np.sqrt(M)))
    print(M, {k: round(v, 2) for k, v in out[M].items()}, flush=True)
json.dump(out, open('../data/dh_queries.json', 'w'), indent=1)
