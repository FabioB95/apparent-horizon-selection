"""Displacement of the minimizer of C_lambda = -V + lambda*Theta from the apparent horizon (Prop. 2, Table 1).
(i) single black hole, isotropic spheres: numerical minimizer vs M^4/(32 lambda);
(ii) Brill-Lindquist d=1.50, 30 even modes: stationary point of C_lambda by Gauss-Newton
     [Hessian 2*lambda*J^T J - Hess V], compared with the linear prediction dc = (J^T J)^{-1} grad V / (2 lambda)."""
import numpy as np, json
from scipy.optimize import minimize_scalar
import bl, reduced as RD
out = {'single': [], 'bl': []}
M = 2.0
def Cs(R, lam):
    psi = 1 + M / (2 * R); H = psi ** -2 * (2 / R - 2 * M / (R * R * psi)); A = 4 * np.pi * R ** 2 * psi ** 4
    return -(4 * np.pi / 3) * R ** 3 + lam * A * H ** 2
for lam in (1, 10, 100, 1000):
    r = minimize_scalar(lambda R: Cs(R, lam), bounds=(M / 2 * 0.999, M / 2 * 3), method='bounded', options={'xatol': 1e-14})
    out['single'].append(dict(lam=lam, numeric=float(r.x - M / 2), predicted=M ** 4 / (32 * lam)))
    print('single', out['single'][-1])
K = 30; d = 1.5
J0 = json.load(open('../data/bl_mots60.json')); c0 = np.array(J0['1.5']['c_out'][:K])
th = np.linspace(1e-3, np.pi / 2, 200)
mu, w = RD.XQ, RD.WQ
P = np.array([np.polynomial.legendre.legval(mu, np.eye(2 * K - 1)[2 * k]) for k in range(K)])   # P_{2k}(mu_q)
def resid(c): return RD.resid(c, d)[0]
def jac(c, eps=1e-7):
    r0 = resid(c); Jm = np.empty((r0.size, c.size))
    for k in range(c.size):
        e = np.zeros_like(c); e[k] = eps; Jm[:, k] = (resid(c + e) - resid(c - e)) / (2 * eps)
    return Jm
def gradV(c): h = bl.shape(c, RD.THQ)[0]; return 2 * np.pi * (P * (w * h ** 2)).sum(axis=1)
def hessV(c): h = bl.shape(c, RD.THQ)[0]; return 4 * np.pi * (P * (w * h)) @ P.T
h0 = bl.shape(c0, th)[0]; Jc = jac(c0); g0 = gradV(c0)
dc_lin1 = np.linalg.solve(Jc.T @ Jc, g0) / 2          # displacement times lambda
for lam in (30, 100, 300, 1000, 3000):
    c = c0.copy()
    for it in range(50):
        Jm = jac(c); r = resid(c)
        g = -gradV(c) + 2 * lam * Jm.T @ r
        Hm = 2 * lam * Jm.T @ Jm - hessV(c)
        step = np.linalg.solve(Hm, g); c = c - step
        if np.max(np.abs(step)) < 1e-11: break
    dh = bl.shape(c, th)[0] - h0; dlin = bl.shape(c0 + dc_lin1 / lam, th)[0] - h0
    out['bl'].append(dict(lam=lam, max_dh=float(np.max(np.abs(dh))), max_dh_linear=float(np.max(np.abs(dlin))),
                          lam_x_max=float(lam * np.max(np.abs(dh))), gn_iters=it + 1))
    print('BL', out['bl'][-1], flush=True)
json.dump(out, open('../data/displacement.json', 'w'), indent=1)
