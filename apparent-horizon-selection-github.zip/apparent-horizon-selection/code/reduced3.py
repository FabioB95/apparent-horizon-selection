"""Three-block reduced cost (c0,c2,c4) with c6.. slaved; full tensor for exhaustive pairwise-marginal tests and D=3 quantum search."""
import numpy as np, json, sys, time
from scipy.optimize import least_squares
import bl, reduced as RD
d = float(sys.argv[1]); N = int(sys.argv[2])
G = [np.linspace(0.55, 0.90, N), np.linspace(0.35, 0.60, N), np.linspace(0.03, 0.15, N)]
T = np.zeros((N, N, N)); A = np.zeros_like(T); V = np.zeros_like(T); Cs = {}
t = time.time()
for i in range(N):
    for j in range(N):
        g = np.zeros(RD.K - 3)
        for k in range(N):
            def f(x): return RD.resid(np.concatenate([[G[0][i], G[1][j], G[2][k]], x]), d)[0]
            r = least_squares(f, g, method='lm', xtol=1e-12, ftol=1e-12, max_nfev=2000); g = r.x
            c = np.concatenate([[G[0][i], G[1][j], G[2][k]], r.x]); rv, dA = RD.resid(c, d)
            T[i, j, k] = np.sum(rv ** 2); A[i, j, k] = np.sum(dA); V[i, j, k] = RD.vol(c); Cs[f'{i},{j},{k}'] = c.tolist()
    print(i, '%.0fs' % (time.time() - t), flush=True)
json.dump(dict(d=d, G=[g.tolist() for g in G], Theta=T.tolist(), A=A.tolist(), V=V.tolist(), C=Cs), open(f'../data/reduced3_d{d}_N{N}.json', 'w'))
