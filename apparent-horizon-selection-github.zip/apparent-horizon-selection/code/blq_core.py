"""Unequal-mass Brill-Lindquist: m1=1, m2=q, centre of mass at the origin, trial surfaces r=h(theta)=sum_l c_l P_l(cos theta) (all l)."""
import numpy as np, json, sys
from numpy.polynomial import legendre as L
from scipy.optimize import least_squares
m = (1.0, 1.0); zc = (0.5, -0.5)
def set_q(q):
    global m, zc
    m = (1.0, q); zc = (q / (1 + q), -1 / (1 + q))
NM = 80
XG, WG = np.polynomial.legendre.leggauss(360); TH = np.arccos(XG)
XQ, WQ = np.polynomial.legendre.leggauss(160); THQ = np.arccos(XQ)
def shape(c, th):
    mu = np.cos(th); h = L.legval(mu, c); d1 = L.legval(mu, L.legder(c)); d2 = L.legval(mu, L.legder(c, 2)); s = np.sin(th)
    return h, -s * d1, s * s * d2 - mu * d1
def psi_grad(r, th, d):
    x, z = r * np.sin(th), r * np.cos(th); p = np.ones_like(r); gx = np.zeros_like(r); gz = np.zeros_like(r)
    for mi, zi in zip(m, zc):
        dz = z - zi * d; ri = np.sqrt(x * x + dz * dz); p += mi / (2 * ri); gx += -mi * x / (2 * ri ** 3); gz += -mi * dz / (2 * ri ** 3)
    return p, gx * np.sin(th) + gz * np.cos(th), gx * np.cos(th) - gz * np.sin(th)
def H(c, th, d):
    h0, h1, h2 = shape(c, th); t = np.tan(th)
    Hf = np.sqrt((h0**2 + h1**2) / h0**2) * (2*h0**3 - h0**2*h1/t - h0**2*h2 + 3*h0*h1**2 - h1**3/t) / (h0**2 + h1**2)**2
    nr = 1 / np.sqrt(1 + h1**2 / h0**2); nt = -h1 / (h0 * np.sqrt(1 + h1**2 / h0**2)); p, gr, gt = psi_grad(h0, th, d)
    return p ** -2 * (Hf + 4 * (nr * gr + nt * gt) / p)
def area(c, d):
    h0, h1, _ = shape(c, THQ); p, _, _ = psi_grad(h0, THQ, d); return float(2 * np.pi * np.sum(WQ * p ** 4 * h0 * np.sqrt(h0 ** 2 + h1 ** 2)))
def vol(c): h = shape(c, THQ)[0]; return float(2 * np.pi / 3 * np.sum(WQ * h ** 3))
def solve(c, d):
    r = least_squares(lambda x: H(x, TH, d), c, method='lm', xtol=1e-15, ftol=1e-15, gtol=1e-15, max_nfev=4000)
    return r.x, float(np.max(np.abs(r.fun)))

def gn(fun, x, tol=1e-13, maxit=60, eps=1e-8):
    """Gauss-Newton with finite-difference Jacobian and backtracking."""
    f = fun(x); nrm = np.linalg.norm(f)
    for it in range(maxit):
        Jm = np.empty((len(f), len(x)))
        for k in range(len(x)):
            e = np.zeros(len(x)); e[k] = eps; Jm[:, k] = (fun(x + e) - f) / eps
        dx = np.linalg.lstsq(Jm, -f, rcond=None)[0]; a = 1.0
        while a > 1e-4:
            xn = x + a * dx; fn = fun(xn); nn = np.linalg.norm(fn)
            if np.isfinite(nn) and nn < nrm: break
            a /= 2
        else: return x, float(np.max(np.abs(f)))
        x, f, nrm = xn, fn, nn
        if np.max(np.abs(f)) < tol: break
    return x, float(np.max(np.abs(f)))
def solve2(c, d): return gn(lambda x: H(x, TH, d), c)

def solve3(c, d):
    from scipy.optimize import least_squares
    r = least_squares(lambda x: H(x, TH, d), c, method='lm', jac='3-point', xtol=1e-15, ftol=1e-15, gtol=1e-15, max_nfev=20000)
    return r.x, float(np.max(np.abs(r.fun)))
