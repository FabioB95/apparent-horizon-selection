"""Outer and inner common MOTS of equal-mass Brill-Lindquist data (bare masses m1=m2=1), d = coordinate separation."""
import numpy as np, json
from scipy.optimize import least_squares
import bl
NM = 30
TH = np.arccos(np.polynomial.legendre.leggauss(200)[0][100:])
def F(c, d): return bl.expansion(c, TH, d)
def solve(c, d):
    r = least_squares(lambda cc: F(cc, d), c, xtol=1e-15, ftol=1e-15, gtol=1e-15, method='lm', max_nfev=4000)
    return r.x, np.max(np.abs(F(r.x, d)))
def geom(c):
    h = bl.shape(np.array(c), np.array([1e-4, np.pi / 2]))[0]; return float(h[0]), float(h[1])
c = np.zeros(NM); c[0] = 1.0; outer = {}
ds = list(np.round(np.arange(0, 1.50, 0.05), 4)) + list(np.round(np.arange(1.50, 1.54, 0.002), 4))
for d in ds:
    c2, res = solve(c, d)
    if res > 1e-9: print('outer fails at', d, res); break
    c = c2; outer[float(d)] = c.copy()
# refine fold by bisection
lo = max(outer); hi = lo + 0.002; clo = outer[lo]
for _ in range(25):
    mid = 0.5 * (lo + hi); cm, res = solve(clo, mid)
    if res < 1e-9: lo, clo = mid, cm
    else: hi = mid
dstar = lo; print('critical separation d* = %.5f' % dstar)
# inner branch by reflection about the fold
keys = sorted(outer); inner = {}
ci = 2 * clo - outer[keys[-1]]
for d in sorted([k for k in keys if k >= 0.9], reverse=True):
    c2, res = solve(ci, d)
    if res > 1e-9:
        print('inner fails at', d, res); break
    if np.max(np.abs(c2 - outer[d])) < 1e-6:
        ci = 2 * c2 - ci; continue          # converged to outer, push further
    inner[float(d)] = c2.copy(); ci = c2 + (c2 - inner.get(float(d), c2)) * 0
print('inner branch from d=%.3f to %.3f' % (min(inner), max(inner)) if inner else 'no inner')
rows = []
for d in keys:
    o = outer[d]; ro = dict(d=d, A_out=float(bl.area(o, d)), geom_out=geom(o), c_out=o.tolist())
    if d in inner: ro.update(A_in=float(bl.area(inner[d], d)), geom_in=geom(inner[d]), c_in=inner[d].tolist())
    rows.append(ro)
for r in rows[::3] + rows[-6:]:
    print(r['d'], round(r['A_out'], 4), r['geom_out'], round(r.get('A_in', np.nan), 4), r.get('geom_in'))
json.dump(dict(dstar=dstar, c_star=clo.tolist(), rows=rows), open('../data/bl_branches.json', 'w'))
