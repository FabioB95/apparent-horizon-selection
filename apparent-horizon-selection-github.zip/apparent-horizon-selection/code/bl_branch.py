import numpy as np, json
from scipy.optimize import least_squares
import bl
NM = 28
TH = np.arccos(np.polynomial.legendre.leggauss(2 * 90)[0][90:])
def F(c, d): return bl.expansion(c, TH, d)
def solve(c, d):
    r = least_squares(lambda cc: F(cc, d), c, xtol=1e-15, ftol=1e-15, gtol=1e-15, method='lm')
    return r.x, np.max(np.abs(F(r.x, d)))
# natural continuation of the outer branch
c = np.zeros(NM); c[0] = 0.5; d = 0.0; br = []
while d < 1.7:
    c2, res = solve(c, d)
    if res > 1e-9: break
    c = c2; br.append((d, c.copy(), bl.area(c, d))); d = round(d + 0.02, 4)
print('outer branch ends near d =', br[-1][0], 'area', br[-1][2])
# pseudo-arclength through the fold: unknowns (c, d)
def G(u, u0, t, ds): return np.concatenate([F(u[:-1], u[-1]), [np.dot(u - u0, t) - ds]])
u = np.append(br[-1][1], br[-1][0]); up = np.append(br[-2][1], br[-2][0]); t = (u - up) / np.linalg.norm(u - up)
path = [u.copy()]; ds = 0.01
for k in range(400):
    guess = u + ds * t
    r = least_squares(lambda x: G(x, u, t, ds), guess, xtol=1e-15, ftol=1e-15, gtol=1e-15, method='lm')
    if np.max(np.abs(r.fun)) > 1e-8: ds /= 2; continue
    t = (r.x - u) / np.linalg.norm(r.x - u); u = r.x; path.append(u.copy())
    if u[-1] < 0.6 or np.min(bl.shape(u[:-1], np.linspace(1e-3, np.pi / 2, 50))[0]) < 0.05: break
P = np.array(path); dmax = P[:, -1].max(); k = np.argmax(P[:, -1])
print('fold at d =', dmax, 'c=', P[k, :3])
inner = [(float(p[-1]), p[:-1].tolist(), float(bl.area(p[:-1], p[-1]))) for p in P[k:]]
outer = [(float(dd), cc.tolist(), float(a)) for dd, cc, a in br] + [(float(p[-1]), p[:-1].tolist(), float(bl.area(p[:-1], p[-1]))) for p in P[:k]]
for dd, cc, a in inner[::max(1, len(inner) // 12)]:
    h = bl.shape(np.array(cc), np.array([1e-3, np.pi / 2]))[0]; print('inner d=%.4f A=%.4f rpole=%.4f req=%.4f' % (dd, a, h[0], h[1]))
json.dump(dict(outer=outer, inner=inner, d_fold=float(dmax)), open('../data/bl_branches.json', 'w'))
