"""Brill--Lindquist time-symmetric data: two punctures of bare mass m1=m2=1 (total M=2) at z=+-d/2.
Axisymmetric, reflection-symmetric trial surfaces r = h(theta) = sum_{l even} c_l P_l(cos theta) about the origin.
On a time-symmetric slice theta_(l) = -theta_(n) = H, the mean curvature in g = psi^4 delta."""
import numpy as np
from numpy.polynomial import legendre as L
from scipy.optimize import least_squares
def psi_and_grad(r, th, d, m=(1.0, 1.0)):
    x, z = r * np.sin(th), r * np.cos(th)
    p = np.ones_like(r); gx = np.zeros_like(r); gz = np.zeros_like(r)
    for mi, zi in zip(m, (d / 2, -d / 2)):
        dz = z - zi; ri = np.sqrt(x * x + dz * dz)
        p += mi / (2 * ri); gx += -mi * x / (2 * ri ** 3); gz += -mi * dz / (2 * ri ** 3)
    # spherical components
    gr = gx * np.sin(th) + gz * np.cos(th); gt = gx * np.cos(th) - gz * np.sin(th)
    return p, gr, gt
def shape(c, th):
    """h, h', h'' for h = sum_k c_k P_{2k}(cos th)"""
    mu = np.cos(th); coef = np.zeros(2 * len(c) - 1); coef[::2] = c
    h = L.legval(mu, coef); dh_dmu = L.legval(mu, L.legder(coef)); d2 = L.legval(mu, L.legder(coef, 2))
    s = np.sin(th); h1 = -s * dh_dmu; h2 = s * s * d2 - mu * dh_dmu
    return h, h1, h2
def expansion(c, th, d):
    h0, h1, h2 = shape(c, th); t = np.tan(th)
    Hf = np.sqrt((h0**2 + h1**2) / h0**2) * (2*h0**3 - h0**2*h1/t - h0**2*h2 + 3*h0*h1**2 - h1**3/t) / (h0**2 + h1**2)**2
    nr = 1 / np.sqrt(1 + h1**2 / h0**2); nt = -h1 / (h0 * np.sqrt(1 + h1**2 / h0**2))
    p, gr, gt = psi_and_grad(h0, th, d)
    return p ** -2 * (Hf + 4 * (nr * gr + nt * gt) / p)
GL_X, GL_W = np.polynomial.legendre.leggauss(64)            # mu in (-1,1)
TH_Q = np.arccos(GL_X)
def area(c, d):
    h0, h1, _ = shape(c, TH_Q); p, _, _ = psi_and_grad(h0, TH_Q, d)
    # dA = psi^4 h sqrt(h^2+h'^2) sin th dth dphi ; d mu = sin th dth
    return 2 * np.pi * np.sum(GL_W * p ** 4 * h0 * np.sqrt(h0 ** 2 + h1 ** 2))
def theta2(c, d):
    """integral of theta_(l)^2 over the surface, physical area element"""
    h0, h1, _ = shape(c, TH_Q); p, _, _ = psi_and_grad(h0, TH_Q, d); H = expansion(c, TH_Q, d)
    return 2 * np.pi * np.sum(GL_W * p ** 4 * h0 * np.sqrt(h0 ** 2 + h1 ** 2) * H ** 2)
def find_mots(d, c0, nmodes=8, ncol=40):
    c = np.zeros(nmodes); c[:len(c0)] = c0
    th = np.arccos(np.polynomial.legendre.leggauss(2 * ncol)[0][ncol:])   # mu in (0,1)
    r = least_squares(lambda cc: expansion(cc, th, d), c, xtol=1e-14, ftol=1e-14, gtol=1e-14)
    res = np.max(np.abs(expansion(r.x, np.linspace(0.02, np.pi / 2, 300), d)))
    return r.x, res
if __name__ == '__main__':
    import json
    out = {}
    for d in [0.0, 0.5, 1.0, 1.2, 1.4, 1.5, 1.52, 1.53, 1.54, 1.56]:
        row = {}
        for lab, R in (('outer', 1.2), ('inner', 0.5)):
            c, res = find_mots(d, [R])
            h0, _, _ = shape(c, np.array([1e-3, np.pi / 2]))
            row[lab] = dict(c=c.tolist(), res=float(res), A=float(area(c, d)), rpole=float(h0[0]), req=float(h0[1]))
        out[d] = row
        print(d, {k: (round(v['res'], 10), round(v['A'], 5), round(v['rpole'], 4), round(v['req'], 4)) for k, v in row.items()})
