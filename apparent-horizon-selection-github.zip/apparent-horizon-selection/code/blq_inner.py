import numpy as np, json, sys
from numpy.polynomial import legendre as L
import blq_core as B
q = float(sys.argv[1]); B.set_q(q); M = 1 + q
c = np.zeros(B.NM); c[0] = M / 2; d = 0.0; stp = 0.02 * M / 2; outer = {}
while stp > 5e-4:
    c2, res = B.solve3(c, d + stp)
    if res < 1e-6: d += stp; c = c2; outer[round(d, 6)] = c.copy()
    else: stp /= 2
print('outer resolved to 1e-9 up to d=%.4f (d/M=%.4f)' % (d, d / M), flush=True)
mu = np.cos(B.THQ); rows = []
keys = sorted(outer); dres = d
targets = [round(dres * (1 - f), 6) for f in (0.0005, 0.003, 0.006, 0.01, 0.02, 0.03, 0.045, 0.06, 0.08)]
for dd in targets:
    kk = min(keys, key=lambda k: abs(k - dd)); co, ro = B.solve3(outer[kk], dd)
    if ro > 1e-6: print(dd, 'outer not resolved'); continue
    found = None
    hco = B.shape(co, B.THQ)[0]; tn = B.THQ[np.argmin(hco)]
    for a, wdt in [(a, w) for a in (0.1, 0.2, 0.3, 0.4) for w in (0.3, 0.6, 1.0)]:
        h = hco * (1 - a * np.exp(-((B.THQ - tn) / wdt) ** 2))
        g = L.legfit(mu, h, B.NM - 1)
        ci, ri = B.solve3(g, dd)
        if ri < 1e-6 and np.max(np.abs(ci - co)) > 1e-4 and B.vol(ci) < B.vol(co) and np.min(B.shape(ci, B.THQ)[0]) > 0.05:
            found = (ci, ri); break
    if found is None: print(dd, 'no inner found'); continue
    ci, ri = found
    rows.append(dict(d=dd, A_out=B.area(co, dd), A_in=B.area(ci, dd), V_out=B.vol(co), V_in=B.vol(ci), res_in=ri))
    print('d=%.4f d/M=%.4f  A_in-A_out=%+.4f  A_out=%.3f  V_out=%.4f V_in=%.4f res %.1e' % (dd, dd / M, rows[-1]['A_in'] - rows[-1]['A_out'], rows[-1]['A_out'], rows[-1]['V_out'], rows[-1]['V_in'], ri), flush=True)
json.dump(dict(q=q, d_resolved=d, rows=rows), open(f'../data/blq_{q}.json', 'w'))
