import numpy as np, json, sys
from scipy.optimize import least_squares
import bl
NM = 40; TH = np.arccos(np.polynomial.legendre.leggauss(240)[0][120:])
J = json.load(open('../data/bl_branches.json')); OUT = {r['d']: np.array(r['c_out']) for r in J['rows']}
IN = {float(k): np.array(v) for k, v in json.load(open('../data/bl_inner.json')).items()}
def pad(c): z = np.zeros(NM); z[:min(NM, len(c))] = c[:NM]; return z
def refine(c, d):
    r = least_squares(lambda cc: bl.expansion(cc, TH, d), pad(c), method='lm', xtol=1e-15, ftol=1e-15, gtol=1e-15, max_nfev=4000)
    return r.x, np.max(np.abs(r.fun))
def classify(c, d):
    co, ci = pad(OUT[d]), pad(IN[d]); x, res = refine(c, d)
    if res > 1e-7: return 'none', res
    do, di = np.max(np.abs(x - co)), np.max(np.abs(x - ci))
    return ('outer' if do < di else 'inner'), res
d = float(sys.argv[1]); R = json.load(open(f'../data/reduced_d{d}_N16.json'))
T, A, V, C = map(np.array, (R['Theta'], R['A'], R['V'], R['C']))
res = {}
for sel, W in (('volume', V), ('area', A / 16 / np.pi)):           # area in units of 16 pi (irreducible-mass squared)
    rows = []
    for lam in [0.1, 0.3, 1, 3, 10, 30, 100, 300, 1000]:
        cost = -W + lam * T; i, j = np.unravel_index(np.argmin(cost), cost.shape)
        lab, r = classify(C[i, j], d); rows.append((lam, int(i), int(j), float(T[i, j]), lab))
        print(d, sel, lam, (i, j), 'Theta=%.4f' % T[i, j], '->', lab)
    res[sel] = rows
json.dump(res, open(f'../data/select_d{d}.json', 'w'))
