"""Scan lambda over 1e-2..1e7 on the (c0,c2) grids and classify the selected cell for volume and area weights:
(i) basin: MOTS reached by the reference finder from the cell; (ii) nearest: MOTS closest in max|h| on the sphere."""
import numpy as np, json
from scipy.optimize import least_squares
import bl
NM = 40; TH = np.arccos(np.polynomial.legendre.leggauss(240)[0][120:]); THT = np.linspace(0, np.pi / 2, 400)
J = json.load(open('../data/bl_branches.json')); OUT = {r['d']: np.array(r['c_out']) for r in J['rows']}
IN = {float(k): np.array(v) for k, v in json.load(open('../data/bl_inner.json')).items()}
def pad(c): z = np.zeros(NM); z[:min(NM, len(c))] = c[:NM]; return z
def hh(c): return bl.shape(pad(c), THT)[0]
def classify(c, d):
    co, ci = pad(OUT[d]), pad(IN[d])
    r = least_squares(lambda cc: bl.expansion(cc, TH, d), pad(c), method='lm', xtol=1e-15, ftol=1e-15, gtol=1e-15, max_nfev=4000)
    basin = 'none' if np.max(np.abs(r.fun)) > 1e-7 else ('O' if np.max(np.abs(r.x - co)) < np.max(np.abs(r.x - ci)) else 'I')
    do, di = np.max(np.abs(hh(c) - hh(co))), np.max(np.abs(hh(c) - hh(ci)))
    return basin, ('O' if do < di else 'I'), float(min(do, di))
LAMS = np.logspace(-2, 7, 361); out = {}
for d, N in ((1.5, 8), (1.5, 12), (1.5, 16), (1.5, 24), (1.51, 16), (1.52, 16)):
    R = json.load(open(f'../data/reduced_d{d}_N{N}.json')); T, A, V, C = map(np.array, (R['Theta'], R['A'], R['V'], R['C']))
    cache = {}; res = {}
    for sel, W in (('volume', V), ('area', A / 16 / np.pi)):
        seg = []
        for lam in LAMS:
            ij = np.unravel_index(np.argmin(-W + lam * T), T.shape)
            if ij not in cache: cache[ij] = classify(C[ij], d)
            b, n, dist = cache[ij]
            if not seg or seg[-1]['cell'] != list(map(int, ij)):
                seg.append(dict(lam_from=float(lam), cell=list(map(int, ij)), Theta=float(T[ij]), basin=b, nearest=n, dist=dist))
        res[sel] = seg
    out[f'{d}_{N}'] = res
    print(f'\n== d={d} N={N}  argminTheta cell', np.unravel_index(np.argmin(T), T.shape))
    for sel in res:
        print(' ', sel, ' | '.join(f"{s['lam_from']:.3g}:{tuple(s['cell'])} b={s['basin']} n={s['nearest']} Th={s['Theta']:.1e}" for s in res[sel]))
json.dump(out, open('../data/lamscan.json', 'w'), indent=1)
# Thresholds of Theorem 2 with the exact apparent horizon added to each d=1.50 grid (Table 5 and Sec. IV.B)
import reduced as RD
co = np.zeros(RD.K); co[:RD.K] = pad(OUT[1.5])[:RD.K]
rv, dA = RD.resid(co, 1.5); W0 = dict(volume=RD.vol(co), area=np.sum(dA) / 16 / np.pi)
thr = {}
for N in (8, 12, 16, 24):
    R = json.load(open(f'../data/reduced_d1.5_N{N}.json')); T, A, V = map(np.array, (R['Theta'], R['A'], R['V']))
    thr[N] = {}
    for sel, W in (('volume', V), ('area', A / 16 / np.pi)):
        m = W > W0[sel]; thr[N][sel] = float(np.max((W[m] - W0[sel]) / T[m]))
    thr[N]['dc0'] = float(R['G0'][1] - R['G0'][0])
    print('lambda* N=%d' % N, {k: round(v, 3) for k, v in thr[N].items()})
out['thresholds_d1.5'] = thr
json.dump(out, open('../data/lamscan.json', 'w'), indent=1)
