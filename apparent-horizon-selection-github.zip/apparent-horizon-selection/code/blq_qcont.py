"""Continuation in mass ratio q of the inner and outer common MOTS of BL data at fixed separation d,
starting from the equal-mass solutions (data/bl_mots60.json). Output data/blq_qcont.json."""
import numpy as np, json, sys
import blq_core as B
B.NM = int(sys.argv[3]) if len(sys.argv) > 3 else B.NM
d = float(sys.argv[1]); qs = [float(x) for x in sys.argv[2].split(',')]
D = json.load(open('../data/bl_mots60.json'))[sys.argv[1]]
def full(ce):
    c = np.zeros(B.NM); ce = ce[:(B.NM + 1) // 2]
    c[0:2 * len(ce):2] = ce; return c
out = {'d': d, 'rows': []}
cur = {'in': full(D['c_in']), 'out': full(D['c_out'])}
for q in qs:
    B.set_q(q); row = {'q': q, 'M': 1 + q}
    for br in ('in', 'out'):
        c, res = B.solve2(cur[br], d)
        if res > 1e-10: c, res = B.solve3(c, d)
        cur[br] = c
        row['A_' + br] = B.area(c, d); row['V_' + br] = B.vol(c); row['res_' + br] = res
        row['c_' + br] = c.tolist()
    row['dA'] = row['A_in'] - row['A_out']; row['dc'] = float(np.max(np.abs(cur['in'] - cur['out'])))
    print(q, row['res_in'], row['res_out'], row['A_in'], row['A_out'], row['dA'], row['V_in'], row['V_out'], row['dc'], flush=True)
    out['rows'].append(row)
json.dump(out, open(f'../data/blq_qcont_d{d}.json', 'w'))
