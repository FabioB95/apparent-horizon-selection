"""Pairwise-marginal approximations of the D=3 cost tensor, compared exhaustively with the full tensor."""
import numpy as np, json, itertools
R = json.load(open('../data/reduced3_d1.5_N8.json')); T, V, A = (np.array(R[k]) for k in ('Theta', 'V', 'A'))
N = T.shape[0]; out = {}
def analyse(C, label):
    full = np.unravel_index(np.argmin(C), C.shape); res = dict(full_min=list(map(int, full)))
    # (i) best pairwise model: least-squares fit of sum of pair tables (projection) to the full tensor
    idx = list(itertools.product(range(N), repeat=3)); nP = 3 * N * N
    X = np.zeros((len(idx), nP)); y = np.array([C[i] for i in idx])
    for r, (i, j, k) in enumerate(idx):
        X[r, 0 * N * N + i * N + j] = 1; X[r, 1 * N * N + i * N + k] = 1; X[r, 2 * N * N + j * N + k] = 1
    w, *_ = np.linalg.lstsq(X, y, rcond=None); Cp = (X @ w).reshape(C.shape)
    res['proj_min'] = list(map(int, np.unravel_index(np.argmin(Cp), C.shape)))
    res['proj_rel_err'] = float(np.linalg.norm(Cp - C) / np.linalg.norm(C - C.mean()))
    res['proj_true_rank'] = int(np.sum(C < C[tuple(res['proj_min'])]))
    # (ii) cheap slice construction: each block's optimum from a 1D scan through the grid centre, pair tables on slices
    mid = N // 2; o = [int(np.argmin(C[:, mid, mid])), int(np.argmin(C[mid, :, mid])), int(np.argmin(C[mid, mid, :]))]
    P01 = C[:, :, o[2]]; P02 = C[:, o[1], :]; P12 = C[o[0], :, :]
    S0, S1, S2 = C[:, o[1], o[2]], C[o[0], :, o[2]], C[o[0], o[1], :]
    Cs = P01[:, :, None] + P02[:, None, :] + P12[None, :, :] - S0[:, None, None] - S1[None, :, None] - S2[None, None, :]
    res['slice_min'] = list(map(int, np.unravel_index(np.argmin(Cs), C.shape)))
    res['slice_true_rank'] = int(np.sum(C < C[tuple(res['slice_min'])]))
    res['slice_evals'] = 3 * N + 3 * N * N; res['full_evals'] = N ** 3
    res['slice_rel_err'] = float(np.linalg.norm(Cs - C) / np.linalg.norm(C - C.mean()))
    # three-body content: residual of the best pairwise model in units of the spread of C
    out[label] = res; print(label, res)
for lam in (1.0, 10.0, 100.0):
    analyse(-V + lam * T, f'volume_lam{lam:g}')
    analyse(-A / (16 * np.pi) + lam * T, f'area_lam{lam:g}')
json.dump(out, open('../data/pairwise.json', 'w'), indent=1)
