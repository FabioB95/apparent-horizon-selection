import sympy as sp
r, th = sp.symbols('r theta', positive=True)
h = sp.Function('h')(th)
F = r - h
Fr, Ft = sp.diff(F, r), sp.diff(F, th) / r          # orthonormal components (r, theta)
nrm = sp.sqrt(Fr**2 + Ft**2); nr, nt = Fr / nrm, Ft / nrm
div = sp.diff(r**2 * nr, r) / r**2 + sp.diff(sp.sin(th) * nt, th) / (r * sp.sin(th))
H0, H1, H2 = sp.symbols('h0 h1 h2')
e = div.subs(r, h).doit()
e = e.subs(sp.Derivative(h, (th, 2)), H2).subs(sp.Derivative(h, th), H1).subs(h, H0)
e = sp.simplify(e); print('H_flat =', e)
nr_s = sp.simplify(nr.subs(r, h).doit().subs(sp.Derivative(h, th), H1).subs(h, H0))
nt_s = sp.simplify(nt.subs(r, h).doit().subs(sp.Derivative(h, th), H1).subs(h, H0))
print('nr =', nr_s); print('nt =', nt_s)
# sanity: sphere h=R -> 2/R
print(sp.simplify(e.subs({H1: 0, H2: 0})))
