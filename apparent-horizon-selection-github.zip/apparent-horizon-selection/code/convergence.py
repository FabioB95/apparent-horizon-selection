"""Mode convergence of the reference finder: inner and outer common MOTS at d=1.40 and 1.50
solved with 10 to 60 even Legendre modes. Residual max|H| on 2000 test angles. Output data/convergence.json."""
import numpy as np, json
from scipy.optimize import least_squares
import bl
D = json.load(open('../data/bl_mots60.json')); TEST = np.linspace(1e-3, np.pi / 2, 2000); out = {}
for d in (1.40, 1.50):
    for NM in (10, 15, 20, 30, 40, 60):
        TH = np.arccos(np.polynomial.legendre.leggauss(6 * NM)[0][3 * NM:])
        row = {}
        for lab in ('in', 'out'):
            g = np.array(D[str(d) if str(d) in D else '%g' % d]['c_' + lab][:NM])
            r = least_squares(lambda c: bl.expansion(c, TH, d), g, method='lm', xtol=1e-15, ftol=1e-15, gtol=1e-15, max_nfev=8000)
            row[lab] = dict(res=float(np.max(np.abs(bl.expansion(r.x, TEST, d)))), A=float(bl.area(r.x, d)))
        out[f'{d}_{NM}'] = dict(d=d, NM=NM, **{f'{k}_{lab}': v[k] for lab, v in row.items() for k in v})
        print(d, NM, 'res %.1e %.1e  A_in %.6f A_out %.6f dA %.6f' % (row['in']['res'], row['out']['res'], row['in']['A'], row['out']['A'], row['in']['A'] - row['out']['A']), flush=True)
json.dump(out, open('../data/convergence.json', 'w'), indent=1)
