import numpy as np, json
from scipy.optimize import least_squares
import bl
NM = 40
TH = np.arccos(np.polynomial.legendre.leggauss(240)[0][120:])
def F(c, d): return bl.expansion(c, TH, d)
J = json.load(open('../data/bl_branches.json')); rows = {r['d']: np.array(r['c_out']) for r in J['rows']}
cst = np.zeros(NM); cst[:30] = J['c_star']; dstar = J['dstar']
def pad(c): z = np.zeros(NM); z[:len(c)] = c; return z
inner = {}
prev = None
for d in [1.531, 1.530, 1.528, 1.525, 1.52, 1.51, 1.50, 1.48, 1.45, 1.42, 1.40, 1.35, 1.30]:
    co = pad(rows[min(rows, key=lambda k: abs(k - d))]) if d not in rows else pad(rows[d])
    guess = 2 * cst - co if prev is None else prev
    best = None
    for g in (guess, 2 * cst - co, prev if prev is not None else guess):
        r = least_squares(lambda cc: F(cc, d), g, xtol=1e-15, ftol=1e-15, gtol=1e-15, method='lm', max_nfev=6000)
        res = np.max(np.abs(r.fun)); dist = np.max(np.abs(r.x - co))
        if dist > 1e-4 and (best is None or res < best[1]): best = (r.x, res)
    if best is None: print(d, 'only outer'); continue
    h = bl.shape(best[0], np.array([1e-4, np.pi / 2]))[0]
    print(d, 'res %.1e' % best[1], 'A_in %.4f' % bl.area(best[0], d), 'A_out %.4f' % bl.area(co, d), 'pole %.4f eq %.4f' % tuple(h))
    if best[1] < 1e-8: inner[d] = best[0].tolist(); prev = best[0]
json.dump(inner, open('../data/bl_inner.json', 'w'))
