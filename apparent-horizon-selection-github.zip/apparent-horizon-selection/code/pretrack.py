"""Expansion pretracking (Schnetter, Herrmann & Pollney 2005, PRD 71, 044033): follow surfaces of constant expansion H=H0 inward from a large sphere to H0=0."""
import numpy as np, json, time
from scipy.optimize import least_squares
import bl
NM = 40; TH = np.arccos(np.polynomial.legendre.leggauss(240)[0][120:])
J = json.load(open('../data/bl_mots60.json'))
out = {}
for d in (1.5, 1.51, 1.52):
    c = np.zeros(NM); c[0] = 3.0; H0 = float(bl.expansion(c, np.array([0.7]), d)[0]); t = time.time(); n = 0
    levels = np.concatenate([np.linspace(H0, 0.05, 25), np.linspace(0.05, 0.0, 6)[1:]])
    for L in levels:
        r = least_squares(lambda x: bl.expansion(x, TH, d) - L, c, method='lm', xtol=1e-14, ftol=1e-14, gtol=1e-14, max_nfev=400); n += 1
        c = r.x
    res = float(np.max(np.abs(bl.expansion(c, TH, d))))
    co = np.array(J[str(d)]['c_out']); ci = np.array(J[str(d)]['c_in'])
    lab = 'outer' if np.max(np.abs(c - co[:NM])) < 1e-5 else ('inner' if np.max(np.abs(c - ci[:NM])) < 1e-5 else 'other')
    out[d] = dict(solves=n, sec=time.time() - t, res=res, result=lab); print(d, out[d], flush=True)
json.dump(out, open('../data/pretrack.json', 'w'), indent=1)
