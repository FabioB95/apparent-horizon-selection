"""Unequal-mass Brill-Lindquist: m1=1, m2=q, centre of mass at the origin, trial surfaces r=h(theta)=sum_l c_l P_l(cos theta) (all l)."""
import numpy as np, json, sys
from numpy.polynomial import legendre as L
from scipy.optimize import least_squares
q = float(sys.argv[1]); m = (1.0, q); zc = (q / (1 + q), -1 / (1 + q))   # positions in units of d
NM = 48
XG, WG = np.polynomial.legendre.leggauss(288); TH = np.arccos(XG)
XQ, WQ = np.polynomial.legendre.leggauss(160); THQ = np.arccos(XQ)
def shape(c, th):
    mu = np.cos(th); h = L.legval(mu, c); d1 = L.legval(mu, L.legder(c)); d2 = L.legval(mu, L.legder(c, 2)); s = np.sin(th)
    return h, -s * d1, s * s * d2 - mu * d1
def psi_grad(r, th, d):
    x, z = r * np.sin(th), r * np.cos(th); p = np.ones_like(r); gx = np.zeros_like(r); gz = np.zeros_like(r)
    for mi, zi in zip(m, zc):
        dz = z - zi * d; ri = np.sqrt(x * x + dz * dz); p += mi / (2 * ri); gx += -mi * x / (2 * ri ** 3); gz += -mi * dz / (2 * ri ** 3)
    return p, gx * np.sin(th) + gz * np.cos(th), gx * np.cos(th) - gz * np.sin(th)
def H(c, th, d):
    h0, h1, h2 = shape(c, th); t = np.tan(th)
    Hf = np.sqrt((h0**2 + h1**2) / h0**2) * (2*h0**3 - h0**2*h1/t - h0**2*h2 + 3*h0*h1**2 - h1**3/t) / (h0**2 + h1**2)**2
    nr = 1 / np.sqrt(1 + h1**2 / h0**2); nt = -h1 / (h0 * np.sqrt(1 + h1**2 / h0**2)); p, gr, gt = psi_grad(h0, th, d)
    return p ** -2 * (Hf + 4 * (nr * gr + nt * gt) / p)
def area(c, d):
    h0, h1, _ = shape(c, THQ); p, _, _ = psi_grad(h0, THQ, d); return float(2 * np.pi * np.sum(WQ * p ** 4 * h0 * np.sqrt(h0 ** 2 + h1 ** 2)))
def vol(c): h = shape(c, THQ)[0]; return float(2 * np.pi / 3 * np.sum(WQ * h ** 3))
def solve(c, d):
    r = least_squares(lambda x: H(x, TH, d), c, method='lm', xtol=1e-15, ftol=1e-15, gtol=1e-15, max_nfev=4000)
    return r.x, float(np.max(np.abs(r.fun)))
M = 1 + q; c = np.zeros(NM); c[0] = M / 2; outer = {}; d = 0.0; step = 0.05 * M / 2
while step > 2e-6:
    c2, res = solve(c, d + step)
    if res < 1e-8: d = d + step; c = c2; outer[d] = c.copy()
    else: step /= 2
dstar = d; clo = c; keys = sorted(outer); print('q=%.2f  d* = %.5f  (d*/M = %.5f)' % (q, dstar, dstar / M), flush=True)
rows = []; prev = None
for f in (0.999, 0.995, 0.99, 0.98, 0.97, 0.96, 0.95, 0.94, 0.93, 0.92):
    d = round(f * dstar, 6)
    co, ro = solve(clo, d)
    g = 2 * clo - co if prev is None else prev
    ci, ri = solve(g, d)
    if np.max(np.abs(ci - co)) < 1e-5 or ri > 1e-7: print(d, 'no distinct inner', ri); continue
    prev = ci
    rows.append(dict(d=d, A_out=area(co, d), A_in=area(ci, d), V_out=vol(co), V_in=vol(ci), res_out=ro, res_in=ri, c_out=co.tolist(), c_in=ci.tolist()))
    print('d=%.4f  A_out=%.4f A_in=%.4f  V_out=%.4f V_in=%.4f  res %.1e %.1e' % (d, rows[-1]['A_out'], rows[-1]['A_in'], rows[-1]['V_out'], rows[-1]['V_in'], ro, ri), flush=True)
json.dump(dict(q=q, dstar=dstar, rows=rows), open(f'../data/blq_{q}.json', 'w'))
