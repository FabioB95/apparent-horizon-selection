"""Checks for the unequal-mass continuation: (i) mode convergence of A_in - A_out at the last resolved q,
(ii) smallest singular value of the collocation Jacobian on both branches (nondegeneracy, needed for the
implicit-function continuation in q). Output data/blq_check.json."""
import numpy as np, json
from scipy.optimize import least_squares
import blq_core as B
out = {}
def solve(c, d):
    r = least_squares(lambda x: B.H(x, B.TH, d), c, method='lm', xtol=1e-15, ftol=1e-15, gtol=1e-15, max_nfev=20000)
    return r.x, float(np.max(np.abs(r.fun)))
def smin(c, d, eps=1e-7):
    f0 = B.H(c, B.TH, d); J = np.empty((len(f0), len(c)))
    for k in range(len(c)):
        e = np.zeros(len(c)); e[k] = eps; J[:, k] = (B.H(c + e, B.TH, d) - B.H(c - e, B.TH, d)) / (2 * eps)
    return float(np.linalg.svd(J, compute_uv=False)[-1])
for dM in (0.73, 0.75):
    R = json.load(open(f'../data/blq_cont_dM{dM}.json'))['rows']
    for row in (R[0], R[len(R) // 2], R[-1]):
        q, d = row['q'], row['d']; B.set_q(q); res = {}
        for NM in (80, 100, 120):
            B.NM = NM; ci, ri = solve(np.array(row['c_in'][:NM]), d); co, ro = solve(np.array(row['c_out'][:NM]), d)
            res[NM] = dict(dA=B.area(ci, d) - B.area(co, d), res_in=ri, res_out=ro)
        B.NM = 120
        s_in, s_out = smin(np.array(row['c_in']), d), smin(np.array(row['c_out']), d)
        out[f'{dM}_{q}'] = dict(dM=dM, q=q, conv=res, smin_in=s_in, smin_out=s_out)
        print(dM, q, {k: ('%.6f' % v['dA'], '%.0e' % v['res_in']) for k, v in res.items()}, 'smin in %.3g out %.3g' % (s_in, s_out), flush=True)
json.dump(out, open('../data/blq_check.json', 'w'), indent=1)
