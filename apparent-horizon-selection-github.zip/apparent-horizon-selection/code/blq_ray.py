"""Continuation of the inner and outer common MOTS along a ray of fixed d/M, M=1+q, from the equal-mass
solutions at d=2r (data/bl_mots60.json). Usage: blq_ray.py r q1,q2,... NM. Output data/blq_ray_r{r}.json."""
import numpy as np, json, sys
import blq_core as B
r = float(sys.argv[1]); qs = [float(x) for x in sys.argv[2].split(',')]; B.NM = int(sys.argv[3])
D = json.load(open('../data/bl_mots60.json'))[f'{2*r:g}']
def full(ce):
    c = np.zeros(B.NM); ce = ce[:(B.NM + 1) // 2]; c[0:2 * len(ce):2] = ce; return c
cur = {'in': full(D['c_in']), 'out': full(D['c_out'])}; out = {'r': r, 'rows': []}
for q in qs:
    B.set_q(q); d = r * (1 + q); s = (1 + q) / 2; row = {'q': q, 'd': d, 'M': 1 + q}
    for br in ('in', 'out'):
        g = cur[br] * s if out['rows'] == [] or True else cur[br]
        g = cur[br] * (s / cur.get('s', 1.0))
        c, res = B.solve2(g, d)
        if res > 1e-10: c, res = B.solve3(c, d)
        cur[br] = c; row['A_' + br] = B.area(c, d); row['V_' + br] = B.vol(c); row['res_' + br] = res; row['c_' + br] = c.tolist()
    cur['s'] = s
    row['dA'] = row['A_in'] - row['A_out']; row['dc'] = float(np.max(np.abs(np.array(row['c_in']) - np.array(row['c_out']))))
    print(q, d, row['res_in'], row['res_out'], row['A_in'], row['A_out'], row['dA'], row['dA'] / row['A_out'], row['V_in'], row['V_out'], row['dc'], flush=True)
    out['rows'].append(row)
    json.dump(out, open(f'../data/blq_ray_r{r}.json', 'w'))
