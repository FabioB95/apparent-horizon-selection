"""Pseudo-arclength continuation of common MOTS through the fold, unequal-mass Brill-Lindquist."""
import numpy as np, json, sys
from scipy.optimize import least_squares
import blq_core as B
q = float(sys.argv[1]); B.set_q(q); M = 1 + q
c = np.zeros(B.NM); c[0] = M / 2
# natural continuation to near the fold (coarse)
path = []; d = 0.0; stp = 0.02 * M / 2
while stp > 1e-3 * M / 2:
    c2, res = B.solve2(c, d + stp)
    if res < 1e-7: d += stp; c = c2; path.append(np.append(c, d))
    else: stp /= 2
print('natural continuation reached d=%.5f' % d, flush=True)
u = path[-1]; t = path[-1] - path[-2]; t /= np.linalg.norm(t); ds = 0.5 * np.linalg.norm(path[-1] - path[-2])
pts = [u.copy()]; dmax = u[-1]
for k in range(3000):
    g = u + ds * t
    x, res = B.gn(lambda x: np.concatenate([B.H(x[:-1], B.TH, x[-1]), [np.dot(x - u, t) - ds]]), g, tol=1e-12, maxit=25)
    class R: pass
    r = R(); r.x = x
    if res > 1e-8:
        ds /= 2
        if ds < 1e-7: print('stalled at', u[-1]); break
        continue
    tn = r.x - u; tn /= np.linalg.norm(tn); u = r.x; t = tn; pts.append(u.copy()); ds = min(ds * 1.3, 0.02)
    dmax = max(dmax, u[-1])
    if u[-1] < 0.9 * dmax and len(pts) > 5: break
P = np.array(pts); kf = int(np.argmax(P[:, -1])); dstar = P[kf, -1]
print('q=%.2f d*=%.5f d*/M=%.5f, points %d' % (q, dstar, dstar / M, len(P)), flush=True)
rows = []
for x in P[kf + 1:]:
    d = x[-1]; ci = x[:-1]
    # outer partner at the same d by Newton from the fold solution
    co, ro = B.solve2(P[kf, :-1], d)
    if np.max(np.abs(co - ci)) < 1e-6: continue
    rows.append(dict(d=float(d), A_out=B.area(co, d), A_in=B.area(ci, d), V_out=B.vol(co), V_in=B.vol(ci), res_out=ro))
for rw in rows[::max(1, len(rows) // 10)]: print('d=%.4f dA=%.4f A_out=%.4f V_out=%.4f V_in=%.4f res_out %.1e' % (rw['d'], rw['A_in'] - rw['A_out'], rw['A_out'], rw['V_out'], rw['V_in'], rw['res_out']))
json.dump(dict(q=q, dstar=float(dstar), rows=rows, fold_c=P[kf, :-1].tolist()), open(f'../data/blq_{q}.json', 'w'))
