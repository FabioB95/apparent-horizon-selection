"""Check: true reflection about W^D (circuit-level, simulated) vs analytic Grover and vs product of block diffusions."""
import numpy as np, json
import qsearch as Q
D = json.load(open('../data/q_experiments.json')); out = {}
for tag, fn, lm in (('D2', '../data/reduced_d1.5_N16.json', 300.0), ('D3', '../data/reduced3_d1.5_N8.json', 100.0)):
    R = json.load(open(fn)); c = -np.array(R['V']) + lm * np.array(R['Theta']); t = int(np.argmin(c))
    m = Q.OneHot(c); pm = int(np.ceil(2.0 * np.sqrt(c.size)))
    tg = Q.true_grover(m, t, pm); an = Q.global_grover(c.size, pm); prod = D[tag]['grover_xy_complete']
    first = lambda g: next((p + 1 for p, v in enumerate(g) if v >= 0.9), None)
    out[tag] = dict(n=int(c.size), true_p90=first(tg), true_max=max(tg), true_argmax=int(np.argmax(tg)) + 1,
                    analytic_maxdiff=float(np.max(np.abs(np.array(tg) - np.array(an)))),
                    prod_p90=first(prod), prod_max=max(prod), prod_argmax=int(np.argmax(prod)) + 1, pmax=pm,
                    pi4sqrt=float(np.pi / 4 * np.sqrt(c.size)))
    print(tag, out[tag])
json.dump(out, open('../data/grover_check.json', 'w'), indent=1)
