import numpy as np, json, itertools
import qsearch as Q
out = {}
lam = 10.0
def norm(c): c = np.asarray(c, float); return (c - c.min()) / (c.max() - c.min())
def softmax_phase(c, be=20.0): return 1 - np.exp(-be * norm(c))
# ---------- D=1: Schwarzschild spheres (isotropic, bare masses 1+1 -> M=2), C_V = -V + lam*Theta
def sphere_cost(N, M=2.0):
    R = np.linspace(0.5, 2.0, N); psi = 1 + M / (2 * R); H = psi ** -2 * (2 / R - 2 * M / (R * R * psi))
    A = 4 * np.pi * R ** 2 * psi ** 4; return -(4 * np.pi / 3) * R ** 3 + lam * A * H ** 2
D1 = []
for N in (4, 8, 16, 32, 64, 128, 256):
    c = sphere_cost(N); t = int(np.argmin(c)); m = Q.OneHot(c)
    pm = int(np.ceil(2.5 * np.sqrt(N))); g = Q.grover_like(m, t, pm, nb=200)
    pstar = next((p + 1 for p, v in enumerate(g) if v >= 0.9), None)
    row = dict(N=N, pstar=pstar, best=max(g), grover_ref=(np.pi / 4) * np.sqrt(N))
    if N <= 64:
        for lab, ph in (('raw', norm(c)), ('softmax', softmax_phase(c))):
            row[lab] = [Q.optimize(m, ph, p, t, starts=8)[1] for p in (1, 2, 3)]
    D1.append(row); print('D1', row, flush=True)
out['D1'] = D1
# ---------- D=2 and D=3 Brill-Lindquist tables (d=1.5), volume selector
for tag, fn, lm in (('D2', '../data/reduced_d1.5_N16.json', 300.0), ('D3', '../data/reduced3_d1.5_N8.json', 100.0)):
    R = json.load(open(fn)); T, V = np.array(R['Theta']), np.array(R['V']); c = -V + lm * T; t = int(np.argmin(c))
    res = dict(n_states=int(c.size), target=[int(x) for x in np.unravel_index(t, c.shape)])
    for kind in ('xy_complete', 'xy_ring'):
        m = Q.OneHot(c, kind); pm = int(np.ceil(2.0 * np.sqrt(c.size)))
        g = Q.grover_like(m, t, pm, nb=200); res['grover_' + kind] = g
        res['pstar_' + kind] = next((p + 1 for p, v in enumerate(g) if v >= 0.9), None)
        for lab, ph in (('raw', norm(c)), ('softmax', softmax_phase(c))):
            res[f'{lab}_{kind}'] = [Q.optimize(m, ph, p, t, starts=6)[1] for p in (1, 2, 3, 4)]
    res['global_grover'] = Q.global_grover(c.size, int(np.ceil(2.0 * np.sqrt(c.size))))
    out[tag] = res; print(tag, {k: (v if not isinstance(v, list) or len(v) < 6 else (round(max(v), 3), len(v))) for k, v in res.items()}, flush=True)
json.dump(out, open('../data/q_experiments.json', 'w'), indent=1, default=float)
