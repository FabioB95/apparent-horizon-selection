"""Inner common MOTS continued to lower separations with 60 modes; outer recomputed with 60 modes as convergence check."""
import numpy as np, json
from scipy.optimize import least_squares
import bl
NM = 60; TH = np.arccos(np.polynomial.legendre.leggauss(360)[0][180:])
def F(c, d): return bl.expansion(c, TH, d)
def pad(c): z = np.zeros(NM); z[:len(c)] = c; return z
J = json.load(open('../data/bl_branches.json')); OUT = {r['d']: np.array(r['c_out']) for r in J['rows']}
I = {float(k): np.array(v) for k, v in json.load(open('../data/bl_inner.json')).items()}
def vol(c): h = bl.shape(c, bl.TH_Q)[0]; return float(2 * np.pi / 3 * np.sum(bl.GL_W * h ** 3))
res = {}
prev = pad(I[1.5]); prev2 = pad(I[1.51])
ds = [1.531, 1.53, 1.528, 1.525, 1.52, 1.51, 1.5, 1.49, 1.48, 1.47, 1.46, 1.45, 1.44, 1.43, 1.42, 1.41, 1.40]
for d in ds:
    g = pad(I[d]) if d in I else 2 * prev - prev2
    r = least_squares(lambda c: F(c, d), g, method='lm', xtol=1e-15, ftol=1e-15, gtol=1e-15, max_nfev=8000)
    rr = np.max(np.abs(r.fun))
    ko = min(OUT, key=lambda k: abs(k - d)); ro = least_squares(lambda c: F(c, d), pad(OUT[ko]), method='lm', xtol=1e-15, ftol=1e-15, gtol=1e-15, max_nfev=8000)
    hi = bl.shape(r.x, np.array([1e-4, np.pi / 2]))[0]; ho = bl.shape(ro.x, np.array([1e-4, np.pi / 2]))[0]
    res[d] = dict(res_in=float(rr), res_out=float(np.max(np.abs(ro.fun))), A_in=float(bl.area(r.x, d)), A_out=float(bl.area(ro.x, d)),
                  V_in=vol(r.x), V_out=vol(ro.x), pole_in=float(hi[0]), eq_in=float(hi[1]), pole_out=float(ho[0]), eq_out=float(ho[1]),
                  c_in=r.x.tolist(), c_out=ro.x.tolist())
    print(d, 'res %.1e/%.1e' % (rr, res[d]['res_out']), 'A %.4f %.4f' % (res[d]['A_in'], res[d]['A_out']), 'V %.4f %.4f' % (res[d]['V_in'], res[d]['V_out']), flush=True)
    if d not in I and rr < 1e-8: prev2, prev = prev, r.x
    elif d in I: prev2, prev = prev, r.x
json.dump(res, open('../data/bl_mots60.json', 'w'))
