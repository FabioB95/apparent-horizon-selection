import numpy as np
lam = 10.0
def norm(c): c = np.asarray(c, float); return (c - c.min()) / (c.max() - c.min())
def softmax_phase(c, be=20.0): return 1 - np.exp(-be * norm(c))
def sphere_cost(N, M=2.0):
    R = np.linspace(0.5, 2.0, N); psi = 1 + M / (2 * R); H = psi ** -2 * (2 / R - 2 * M / (R * R * psi))
    A = 4 * np.pi * R ** 2 * psi ** 4; return -(4 * np.pi / 3) * R ** 3 + lam * A * H ** 2
