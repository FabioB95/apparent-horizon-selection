"""Straight-line evaluation of the per-node integrand of the cost, with every arithmetic
operation counted.  The result is checked against blq_core.H / area / vol, so the operation
count of Sec. V.D and Appendix B is the count of a program that actually computes the cost.

Per node q the oracle needs: h, h', h'' (from K coefficients), psi and grad psi (two punctures),
the flat mean curvature and unit normal, the expansion theta, the area element, and the
accumulation of w_q * (theta^2 dA) and w_q * h^3.  Products with classical constants
(Legendre values, sin/cos of the node, quadrature weights, masses) are counted separately,
since a reversible circuit implements them by shift-and-add.
"""
import numpy as np, json
from numpy.polynomial import legendre as L
import blq_core as B

class Cnt:
    def __init__(s): s.c = dict(mul=0, cmul=0, add=0, recip=0, sqrt=0, rsqrt=0)
C = Cnt()
def mul(a, b): C.c['mul'] += 1; return a * b
def cmul(k, a): C.c['cmul'] += 1; return k * a          # multiplication by a classical constant
def add(a, b): C.c['add'] += 1; return a + b
def sub(a, b): C.c['add'] += 1; return a - b
def recip(a): C.c['recip'] += 1; return 1.0 / a
def sqrt(a): C.c['sqrt'] += 1; return np.sqrt(a)
def rsqrt(a): C.c['rsqrt'] += 1; return 1.0 / np.sqrt(a)

def node(c, th, d, m, zc):
    """Returns theta, dA/dtheta-measure factor and h^3 at one node, counting operations."""
    K = len(c); mu = np.cos(th); s = np.sin(th); cot = mu / s
    P = L.legvander(np.atleast_1d(mu), K - 1)[0]; dP = np.array([L.legval(mu, L.legder(np.eye(K)[k])) for k in range(K)])
    d2P = np.array([L.legval(mu, L.legder(np.eye(K)[k], 2)) for k in range(K)])
    # h, h' = -s dh/dmu, h'' = s^2 d2h/dmu2 - mu dh/dmu : K constant-multiplications and K-1 additions each
    h0 = c[0] * P[0]; g1 = c[0] * dP[0]; g2 = c[0] * d2P[0]; C.c['cmul'] += 3
    for k in range(1, K):
        h0 = add(h0, cmul(P[k], c[k])); g1 = add(g1, cmul(dP[k], c[k])); g2 = add(g2, cmul(d2P[k], c[k]))
    h1 = cmul(-s, g1); h2 = sub(cmul(s * s, g2), cmul(mu, g1))
    # conformal factor and gradient, two punctures
    x = cmul(s, h0); z = cmul(mu, h0); p = 1.0; gx = 0.0; gz = 0.0
    for mi, zi in zip(m, zc):
        dz = sub(z, zi * d); r2 = add(mul(x, x), mul(dz, dz)); ir = rsqrt(r2)
        p = add(p, cmul(mi / 2, ir)); ir3 = mul(mul(ir, ir), ir); f = cmul(-mi / 2, ir3)
        gx = add(gx, mul(f, x)); gz = add(gz, mul(f, dz))
    gr = add(cmul(s, gx), cmul(mu, gz)); gt = sub(cmul(mu, gx), cmul(s, gz))
    # flat mean curvature and unit normal
    a0 = mul(h0, h0); a1 = mul(h1, h1); n2 = add(a0, a1); nn = sqrt(n2); inn = recip(nn)
    ih0 = recip(h0)
    a03 = mul(a0, h0); t1 = mul(a0, h1); t2 = mul(a0, h2); t3 = mul(h0, a1); t4 = mul(a1, h1)
    num = sub(sub(add(cmul(2, a03), cmul(3, t3)), add(cmul(cot, t1), t2)), cmul(cot, t4))
    den = mul(n2, n2); iden = recip(den)
    Hf = mul(mul(mul(nn, ih0), num), iden)                     # sqrt((h0^2+h1^2)/h0^2) = nn/h0 for h0>0
    nr = mul(h0, inn); nt = cmul(-1, mul(h1, inn))
    ip = recip(p); ip2 = mul(ip, ip)
    dpsi = add(mul(nr, gr), mul(nt, gt))
    th_l = mul(ip2, add(Hf, cmul(4, mul(dpsi, ip))))
    # area element psi^4 h sqrt(h^2+h'^2) and integrands
    p2 = mul(p, p); p4 = mul(p2, p2); dA = mul(mul(p4, h0), nn)
    f_theta = mul(mul(th_l, th_l), dA); f_vol = mul(a0, h0)
    return th_l, dA, f_theta, f_vol

if __name__ == '__main__':
    q = 1.0; d = 1.5; B.set_q(q); K = 22
    D = json.load(open('../data/bl_mots60.json'))['1.5']
    ce = np.array(D['c_out'][:11]); c = np.zeros(K); c[0:2 * len(ce):2] = ce; c = c[:K]
    errs = []
    for th in (0.3, 0.9, 1.4, 2.2):
        C.c = dict(mul=0, cmul=0, add=0, recip=0, sqrt=0, rsqrt=0)
        t, dA, ft, fv = node(c, th, d, B.m, B.zc)
        ref = B.H(c, np.array([th]), d)[0]; errs.append(abs(t - ref))
        h0, h1, _ = B.shape(c, np.array([th])); p, _, _ = B.psi_grad(h0, np.array([th]), d)
        errs.append(abs(dA - (p ** 4 * h0 * np.sqrt(h0 ** 2 + h1 ** 2))[0]))
    cnt = dict(C.c); print('max |straight-line - reference| =', max(errs)); print('per node, K=%d:' % K, cnt)
    # accumulation: w_q * f_theta, w_q * f_vol (2 constant mults, 2 adds) per node
    cnt['cmul'] += 2; cnt['add'] += 2
    json.dump(dict(K=K, per_node=cnt, check=float(max(errs))), open('../data/oracle_count.json', 'w'), indent=1)
