"""Initialization sensitivity of a spectral Newton (Levenberg-Marquardt) finder on BL data with two common MOTS."""
import numpy as np, json, time
from scipy.optimize import least_squares
import bl
NM = 40; TH = np.arccos(np.polynomial.legendre.leggauss(240)[0][120:])
J = json.load(open('../data/bl_branches.json')); OUT = {r['d']: np.array(r['c_out']) for r in J['rows']}
IN = {float(k): np.array(v) for k, v in json.load(open('../data/bl_inner.json')).items()}
def pad(c): z = np.zeros(NM); z[:min(len(c), NM)] = c[:NM]; return z
out = {}
for d in (1.50, 1.51, 1.52):
    co, ci = pad(OUT[d]), pad(IN[d]); res = []; t0 = time.time()
    for R0 in np.linspace(0.4, 2.0, 33):
        for e2 in (0.0, 0.2, 0.4, 0.6):            # spheres and prolate guesses c2 = e2*R0
            c = np.zeros(NM); c[0] = R0; c[1] = e2 * R0
            r = least_squares(lambda x: bl.expansion(x, TH, d), c, method='lm', xtol=1e-14, ftol=1e-14, gtol=1e-14, max_nfev=300)
            ok = np.max(np.abs(r.fun)) < 1e-8
            lab = 'fail' if not ok else ('outer' if np.max(np.abs(r.x - co)) < 1e-5 else ('inner' if np.max(np.abs(r.x - ci)) < 1e-5 else 'other'))
            res.append(lab)
    dt = (time.time() - t0) / len(res)
    out[d] = {k: res.count(k) for k in ('outer', 'inner', 'other', 'fail')}; out[d]['n'] = len(res); out[d]['sec_per_solve'] = dt
    print(d, out[d], flush=True)
json.dump(out, open('../data/nr_basins.json', 'w'), indent=1)
