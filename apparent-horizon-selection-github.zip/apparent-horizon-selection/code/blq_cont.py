"""Continuation in the mass ratio q from the equal-mass inner and outer common MOTS.
Bare masses (1, q), punctures on the z axis with the centre of mass at the origin,
separation d = (d/M) (1+q) at fixed d/M.  Surfaces r = h(theta) with all Legendre modes.
Usage: python blq_cont.py dM  [qmin] [dq]
"""
import numpy as np, json, sys
import blq_core as B
B.NM = 120
dM = float(sys.argv[1]); qmin = float(sys.argv[2]) if len(sys.argv) > 2 else 0.8
dq0 = float(sys.argv[3]) if len(sys.argv) > 3 else 0.02
D = json.load(open('../data/bl_mots60.json'))
key = min(D, key=lambda k: abs(float(k) - 2 * dM)); assert abs(float(key) - 2 * dM) < 1e-9, key
def lift(ce):
    c = np.zeros(B.NM); c[0:2 * len(ce):2] = ce; return c[:B.NM]
def solve(c, d):
    from scipy.optimize import least_squares
    r = least_squares(lambda x: B.H(x, B.TH, d), c, method='lm', xtol=1e-15, ftol=1e-15, gtol=1e-15, max_nfev=20000)
    return r.x, float(np.max(np.abs(r.fun)))
rows = []; br = {}
for name in ('in', 'out'):
    B.set_q(1.0); c, res = solve(lift(D[key]['c_' + name]), 2 * dM)
    br[name] = [(1.0, c)]; print(name, 'q=1 res %.1e A=%.4f' % (res, B.area(c, 2 * dM)), flush=True)
q = 1.0; dq = dq0
while q - dq >= qmin - 1e-12 and dq > 1e-3:
    qn = round(q - dq, 6); B.set_q(qn); d = dM * (1 + qn); ok = True; sol = {}
    for name in ('in', 'out'):
        hist = br[name]
        if len(hist) >= 2:   # secant predictor in q
            (q1, c1), (q2, c2) = hist[-2], hist[-1]; g = c2 + (c2 - c1) * (qn - q2) / (q2 - q1)
        else: g = hist[-1][1]
        c, res = solve(g, d)
        if res > 1e-8 or np.min(B.shape(c, B.THQ)[0]) < 0.02: ok = False; break
        sol[name] = (c, res)
    if not ok: dq /= 2; print('  step halved ->', dq, flush=True); continue
    if np.max(np.abs(sol['in'][0] - sol['out'][0])) < 1e-3: print('branches merged at q', qn); break
    for name in ('in', 'out'): br[name].append((qn, sol[name][0]))
    q = qn; M = 1 + q
    ci, co = sol['in'][0], sol['out'][0]
    row = dict(q=q, d=d, dM=dM, A_in=B.area(ci, d), A_out=B.area(co, d), V_in=B.vol(ci), V_out=B.vol(co),
               res_in=sol['in'][1], res_out=sol['out'][1], c_in=ci.tolist(), c_out=co.tolist())
    rows.append(row)
    print('q=%.3f d=%.4f  A_in/M^2=%.5f A_out/M^2=%.5f  dA/A_out=%+.2e  V_in=%.4f V_out=%.4f  res %.1e %.1e' % (
        q, d, row['A_in'] / M**2, row['A_out'] / M**2, row['A_in'] / row['A_out'] - 1, row['V_in'], row['V_out'], row['res_in'], row['res_out']), flush=True)
json.dump(dict(dM=dM, rows=rows), open(f'../data/blq_cont_dM{dM}.json', 'w'))
