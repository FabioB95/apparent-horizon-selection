"""Reduced cost on a grid of the two leading modes (c0, c2): higher modes c4..c_{2K} are slaved by minimizing Theta."""
import numpy as np, json, sys, time
from scipy.optimize import least_squares
import bl
K = 22
XQ, WQ = np.polynomial.legendre.leggauss(160); M = XQ > 0; XQ, WQ = XQ[M], 2 * WQ[M]; THQ = np.arccos(XQ)
def resid(c, d):
    h0, h1, _ = bl.shape(c, THQ); p, _, _ = bl.psi_and_grad(h0, THQ, d)
    dA = 2 * np.pi * WQ * p ** 4 * h0 * np.sqrt(h0 ** 2 + h1 ** 2)
    return np.sqrt(dA) * bl.expansion(c, THQ, d), dA
def vol(c):
    h = bl.shape(c, THQ)[0]; return 2 * np.pi / 3 * np.sum(WQ * h ** 3)
def slave(c0, c2, d, guess):
    def f(x): return resid(np.concatenate([[c0, c2], x]), d)[0]
    r = least_squares(f, guess, method='lm', xtol=1e-13, ftol=1e-13, max_nfev=3000)
    c = np.concatenate([[c0, c2], r.x]); rv, dA = resid(c, d)
    return c, float(np.sum(rv ** 2)), float(np.sum(dA)), float(vol(c))
if __name__ == '__main__':
    d = float(sys.argv[1]); N = int(sys.argv[2]); a0, b0, a2, b2 = map(float, sys.argv[3:7])
    G0 = np.linspace(a0, b0, N); G2 = np.linspace(a2, b2, N); out = dict(d=d, G0=G0.tolist(), G2=G2.tolist(), Theta=[], A=[], V=[], C=[])
    t = time.time(); guess = np.zeros(K - 2)
    for i, c0 in enumerate(G0):
        rowT, rowA, rowV, rowC = [], [], [], []; g = guess.copy()
        for j, c2 in enumerate(G2):
            c, T, A, V = slave(c0, c2, d, g); g = c[2:]
            if j == 0: guess = c[2:]
            rowT.append(T); rowA.append(A); rowV.append(V); rowC.append(c.tolist())
        out['Theta'].append(rowT); out['A'].append(rowA); out['V'].append(rowV); out['C'].append(rowC)
        print(i, '%.0fs' % (time.time() - t), np.round(rowT, 4).tolist(), flush=True)
    json.dump(out, open(f'../data/reduced_d{d}_N{N}.json', 'w'))
