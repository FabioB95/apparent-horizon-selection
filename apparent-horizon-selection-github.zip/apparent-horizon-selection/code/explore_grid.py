import numpy as np, json, itertools
import bl
J = json.load(open('../data/bl_branches.json')); outer = {r['d']: np.array(r['c_out']) for r in J['rows']}
I = {float(k): np.array(v) for k, v in json.load(open('../data/bl_inner.json')).items()}
def vol(c):
    h = bl.shape(np.array(c), bl.TH_Q)[0]; return 2 * np.pi / 3 * np.sum(bl.GL_W * h ** 3)
for d in (1.5, 1.51, 1.52):
    co = outer[min(outer, key=lambda k: abs(k - d))]; ci = I[d]
    print(d, 'outer c[:5]', np.round(co[:5], 4), 'V', round(vol(co), 4), 'A', round(bl.area(co, d), 3))
    print(d, 'inner c[:5]', np.round(ci[:5], 4), 'V', round(vol(ci), 4), 'A', round(bl.area(ci, d), 3))
    # best 3-mode approximations (truncate) residual
    for lab, c in (('out', co), ('in', ci)):
        t = np.zeros(3); t[:] = c[:3]
        print('   truncated', lab, 'Theta=', bl.theta2(t, d))
