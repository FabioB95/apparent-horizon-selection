"""Toffoli-count estimate of a coherent cost oracle and break-even against classical exhaustive search.
The per-node operation counts are those of the straight-line program of oracle_count.py, which
reproduces the expansion and area element of the reference finder to 3e-14.
Cost model (b-bit fixed point), with kappa scaling every b^2 term:
  register x register multiplication   kappa b^2 Toffoli  (kappa ~ 1: truncated product with a b-Toffoli adder [Gidney 2018];
                                                           kappa ~ 2-3: full product with controlled ripple-carry adders)
  multiplication by a classical const  kappa b^2 Toffoli  (shift-and-add; canonical signed digits give ~2/3 of this)
  addition / subtraction               2b Toffoli         (ripple-carry adder, Cuccaro et al.)
  reciprocal  y <- y(2 - x y)          3 Newton steps x 2 mult = 6 kappa b^2
  inverse sqrt y <- y(3 - x y^2)/2     3 Newton steps x 3 mult = 9 kappa b^2
  sqrt = x * rsqrt(x)                  10 kappa b^2
Initial Newton guesses come from a small lookup table whose cost is neglected; compute + uncompute doubles the count.
Queries: idealized Grover with one known marked item (pi/4 sqrt M) and Durr-Hoyer minimum finding
(mean and 90% quantile from dh_queries.py). Output data/oracle_cost.json.
"""
import json, math
cnt = json.load(open('../data/oracle_count.json'))['per_node']
dhq = json.load(open('../data/dh_queries.json'))
C_MEAN = round(sum(v['c_mean'] for v in dhq.values()) / len(dhq), 1)     # ~2.8
C_Q90 = round(sum(v['c_q90'] for v in dhq.values()) / len(dhq), 1)       # ~4.8
b, Q, K = 32, 32, 22
coef_b2 = cnt['mul'] + cnt['cmul'] + 6 * cnt['recip'] + 9 * cnt['rsqrt'] + 10 * cnt['sqrt']
coef_b = 2 * cnt['add']
def T_O(kappa=1.0, bb=b): return 2 * Q * (kappa * coef_b2 * bb * bb + coef_b * bb)
F = Q * sum(cnt.values())                     # classical: one operation per arithmetic step
QC = {'grover_known_marked': math.pi / 4, 'dh_mean': C_MEAN, 'dh_q90': C_Q90}
out = dict(b=b, Q=Q, K=K, per_node_ops=cnt, coef_b2=coef_b2, coef_b=coef_b, per_node_toffoli=T_O() / (2 * Q),
           T_oracle=T_O(), flops=F, ratio=T_O() / F, query_constants=QC)
out['breakeven'] = {f'kappa{k:g}': {q: (c * T_O(k) / F) ** 2 for q, c in QC.items()} for k in (0.5, 1, 2, 3)}
out['breakeven_bits'] = {f'b{bb}': {q: (c * T_O(1, bb) / F) ** 2 for q, c in QC.items()} for bb in (16, 24, 32, 48)}
out['breakeven_slow1e4_dh_mean'] = (C_MEAN * T_O() / F * 1e4) ** 2
out['D2N16_quantum_over_classical'] = {q: c * 16 * T_O() / (256 * F) for q, c in QC.items()}
Mx = 16 ** 6; rate = 1e6                       # D=6, N=16 at a 1 MHz logical Toffoli rate, serial oracle
out['D6N16'] = dict(M=Mx, hours_grover=math.pi / 4 * math.sqrt(Mx) * T_O() / rate / 3600,
                    hours_dh_mean=C_MEAN * math.sqrt(Mx) * T_O() / rate / 3600,
                    classical_flops=Mx * F, classical_seconds_at_1GFLOPs=Mx * F / 1e9)
print(json.dumps(out, indent=1)); json.dump(out, open('../data/oracle_cost.json', 'w'), indent=1)
