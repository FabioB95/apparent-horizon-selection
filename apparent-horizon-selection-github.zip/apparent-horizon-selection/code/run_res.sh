for N in 8 12 24; do python3 reduced.py 1.5 $N 0.55 0.9 0.35 0.6 > ../data/log_red$N.txt 2>&1; python3 select_N.py 1.5 $N > ../data/log_sel$N.txt 2>&1; done
python3 select_N.py 1.5 16 > ../data/log_sel16.txt 2>&1
echo done > ../data/res_done
