"""Refine the minimizers of the full 8^3 cost tensor (Table tab:pairwise) with the reference finder and classify them."""
import numpy as np, json
from scipy.optimize import least_squares
import bl
NM = 40; TH = np.arccos(np.polynomial.legendre.leggauss(240)[0][120:])
J = json.load(open('../data/bl_branches.json')); OUT = {r['d']: np.array(r['c_out']) for r in J['rows']}
IN = {float(k): np.array(v) for k, v in json.load(open('../data/bl_inner.json')).items()}
def pad(c): z = np.zeros(NM); z[:min(NM, len(c))] = c[:NM]; return z
def refine(c, d):
    r = least_squares(lambda cc: bl.expansion(cc, TH, d), pad(c), method='lm', xtol=1e-15, ftol=1e-15, gtol=1e-15, max_nfev=4000)
    return r.x, np.max(np.abs(r.fun))
R = json.load(open('../data/reduced3_d1.5_N8.json')); d = R['d']
T, A, V = (np.array(R[k]) for k in ('Theta', 'A', 'V')); C = R['C']
co, ci = pad(OUT[d]), pad(IN[d]); out = {}
for key in sorted({'7,1,1', '5,2,2', '7,2,2', '0,7,7'}):
    x, res = refine(np.array(C[key]), d)
    do, di = np.max(np.abs(x - co)), np.max(np.abs(x - ci))
    lab = 'none' if res > 1e-7 else ('outer' if do < di else 'inner')
    i, j, k = map(int, key.split(','))
    out[key] = dict(label=lab, res=float(res), Theta=float(T[i, j, k]), V=float(V[i, j, k]), A=float(A[i, j, k]), dist_out=float(do), dist_in=float(di))
    print(key, out[key])
json.dump(out, open('../data/refine3.json', 'w'), indent=1)
