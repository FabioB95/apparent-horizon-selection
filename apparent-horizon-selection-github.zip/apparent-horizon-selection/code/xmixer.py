import numpy as np, json, itertools
from scipy.optimize import minimize
import qsearch as Q
from q_experiments_helpers import sphere_cost, norm, softmax_phase
import sys
ENC = sys.argv[1] if len(sys.argv) > 1 else 'softmax'
N = 8; c = (softmax_phase if ENC == 'softmax' else norm)(sphere_cost(N)); t = int(np.argmin(c)); mu = 2.0
bits = np.array(list(itertools.product([0, 1], repeat=N)))[:, ::-1]      # state index -> bits (qubit k = bit k)
E = bits @ c + mu * (bits.sum(1) - 1) ** 2
tgt = int(np.sum(2 ** np.arange(N) * (np.arange(N) == t)))
X = [np.array([[0, 1], [1, 0]])]
def mixX(psi, b):
    s = np.cos(b) * np.eye(2) - 1j * np.sin(b) * X[0]; psi = psi.reshape([2] * N)
    for k in range(N): psi = np.moveaxis(np.tensordot(s, np.moveaxis(psi, k, 0), axes=1), 0, k)
    return psi.reshape(-1)
def run(x, p):
    psi = np.ones(2 ** N, complex) / np.sqrt(2 ** N)
    for g, b in zip(x[:p], x[p:]): psi = mixX(np.exp(-1j * g * E) * psi, b)
    return psi
out = {}
rng = np.random.default_rng(1)
for p in (1, 2, 3, 4):
    best = None
    for s in range(12):
        x0 = np.concatenate([rng.uniform(0, np.pi, p), rng.uniform(0, np.pi, p)])
        r = minimize(lambda x: float(np.sum(np.abs(run(x, p)) ** 2 * E)), x0, method='L-BFGS-B')
        psi = run(r.x, p); pr = np.abs(psi) ** 2; valid = float(sum(pr[i] for i in range(2 ** N) if bits[i].sum() == 1))
        if best is None or r.fun < best[0]: best = (r.fun, float(pr[tgt]), valid)
    out[f'X_p{p}'] = dict(P=best[1], valid=best[2])
    for kind in ('xy_complete', 'xy_ring'):
        m = Q.OneHot(c, kind); out[f'{kind}_p{p}'] = dict(P=Q.optimize(m, c, p, t, starts=12)[1], valid=1.0)
    print(p, {k: v for k, v in out.items() if k.endswith(f'p{p}')}, flush=True)
json.dump(out, open('../data/xmixer.json' if ENC == 'softmax' else '../data/xmixer_raw.json', 'w'), indent=1)
