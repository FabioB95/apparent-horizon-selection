import json, numpy as np, os
import bl
HERE = os.path.dirname(os.path.abspath(__file__)); D = os.path.join(HERE, '..', 'data'); FG = os.path.join(HERE, '..', 'paper', 'figs')
J = lambda f: json.load(open(os.path.join(D, f)))
def co(xs, ys, f='%.5g'): return ' '.join('(' + (f % x) + ',' + (f % y) + ')' for x, y in zip(xs, ys))
def W(n, s): open(os.path.join(FG, n), 'w').write(s); print('wrote', n)
AX = r'tick label style={font=\scriptsize}, label style={font=\small}, legend style={font=\scriptsize, draw=none, fill=none}, legend cell align=left'
# ---------------- Fig 1: areas and volumes of the two common MOTS
M = J('bl_mots60.json'); ds = sorted(map(float, M)); dstar = J('bl_branches.json')['dstar']
Bo = J('bl_branches.json')['rows']
dA = [M[str(d)]['A_in'] - M[str(d)]['A_out'] for d in ds]
s = [r'\begin{tikzpicture}', r'\begin{groupplot}[group style={group size=2 by 1, horizontal sep=1.2cm}, width=4.4cm, height=4.2cm, ' + AX + ']',
     r'\nextgroupplot[xlabel={separation $d$}, ylabel={$A_{\rm in}-A_{\rm out}$}, xmin=1.39, xmax=1.54, ymin=0, scaled x ticks=false, xtick={1.4,1.45,1.5}, xticklabel style={/pgf/number format/fixed}]',
     rf'\addplot[cOrange, thick, mark=*, mark size=0.8pt] coordinates {{{co(ds, dA)}}};',
     rf'\addplot[black, densely dotted] coordinates {{({dstar:.4f},0) ({dstar:.4f},3.4)}};',
     r'\node[anchor=north east, font=\scriptsize] at (rel axis cs:0.97,0.97) {(a)};',
     r'\nextgroupplot[xlabel={separation $d$}, ylabel={coordinate volume $V$}, xmin=1.39, xmax=1.54, scaled x ticks=false, xtick={1.4,1.45,1.5}, xticklabel style={/pgf/number format/fixed}, legend columns=2, legend style={at={(0.5,1.03)}, anchor=south}]',
     rf'\addplot[cBlue, thick] coordinates {{{co(ds, [M[str(d)]["V_out"] for d in ds])}}}; \addlegendentry{{outer (AH)}}',
     rf'\addplot[cOrange, thick, dashed] coordinates {{{co(ds, [M[str(d)]["V_in"] for d in ds])}}}; \addlegendentry{{inner}}',
     rf'\addplot[black, densely dotted, forget plot] coordinates {{({dstar:.4f},0.9) ({dstar:.4f},3.2)}};',
     r'\node[anchor=north east, font=\scriptsize] at (rel axis cs:0.97,0.97) {(b)};',
     r'\end{groupplot}', r'\end{tikzpicture}']
W('fig_areas.tex', '\n'.join(s))
# ---------------- Fig 2: shapes in the xz plane
th = np.linspace(1e-4, np.pi - 1e-4, 121)
s = [r'\begin{tikzpicture}', r'\begin{groupplot}[group style={group size=2 by 1, horizontal sep=0.5cm, y descriptions at=edge left}, width=4.3cm, height=5.6cm, axis equal image, xmin=-1.0, xmax=1.0, ymin=-1.45, ymax=1.45, xlabel={$x$}, ylabel={$z$}, ' + AX + ']']
for d, lab in ((1.5, '(a) $d=1.50$'), (1.4, '(b) $d=1.40$')):
    s.append(r'\nextgroupplot')
    for key, sty in (('c_out', 'cBlue, thick'), ('c_in', 'cOrange, thick, dashed')):
        h = bl.shape(np.array(M[str(d)][key]), th)[0]; x, z = h * np.sin(th), h * np.cos(th)
        s.append(rf'\addplot[{sty}] coordinates {{{co(np.concatenate([x, -x[::-1]]), np.concatenate([z, z[::-1]]), "%.4f")}}};')
    s.append(rf'\addplot[only marks, mark=x, mark size=2pt, black] coordinates {{(0,{d/2}) (0,{-d/2})}};')
    s.append(rf'\node[anchor=north west, font=\scriptsize] at (rel axis cs:0.03,0.98) {{{lab}}};')
s += [r'\end{groupplot}', r'\end{tikzpicture}']
W('fig_shapes.tex', '\n'.join(s))
# ---------------- Fig 3: reduced landscape and selections at d=1.5
R = J('reduced_d1.5_N16.json'); T = np.array(R['Theta']); G0, G2 = R['G0'], R['G2']
pts = ' '.join(f'({G0[i]:.4f},{G2[j]:.4f}) [{np.log10(T[i, j]):.3f}]' for i in range(16) for j in range(16))
sel = J('select_d1.5.json'); vv = [r for r in sel['volume'] if r[0] == 300][0]; aa = [r for r in sel['area'] if r[0] == 300][0]
co_, ci_ = M['1.5']['c_out'], M['1.5']['c_in']
s = [r'\begin{tikzpicture}', r'\begin{axis}[width=6.3cm, height=5.6cm, xlabel={$c_0$}, ylabel={$c_2$}, colorbar, colormap/viridis, colorbar style={ylabel={$\log_{10}\Theta$}, font=\scriptsize}, enlargelimits=false, ' + AX + ', legend columns=2, legend style={at={(0.5,1.03)}, anchor=south, /tikz/every even column/.append style={column sep=5pt}}]',
     rf'\addplot[matrix plot*, mesh/cols=16, mesh/ordering=y varies, point meta=explicit, forget plot] coordinates {{{pts}}};',
     rf'\addplot[only marks, mark=square*, mark size=2.6pt, white, draw=black] coordinates {{({G0[vv[1]]:.4f},{G2[vv[2]]:.4f})}}; \addlegendentry{{volume selector}}',
     rf'\addplot[only marks, mark=diamond*, mark size=3pt, cOrange, draw=black] coordinates {{({G0[aa[1]]:.4f},{G2[aa[2]]:.4f})}}; \addlegendentry{{area selector}}',
     rf'\addplot[only marks, mark=o, mark size=3pt, very thick, white, legend image post style={{black}}] coordinates {{({co_[0]:.4f},{co_[1]:.4f})}}; \addlegendentry{{outer MOTS}}',
     rf'\addplot[only marks, mark=triangle, mark size=3pt, very thick, white, legend image post style={{black}}] coordinates {{({ci_[0]:.4f},{ci_[1]:.4f})}}; \addlegendentry{{inner MOTS}}',
     r'\end{axis}', r'\end{tikzpicture}']
W('fig_landscape.tex', '\n'.join(s))
# ---------------- Fig 4: Grover structure
Q = J('q_experiments.json'); D1 = Q['D1']
Ns = [r['N'] for r in D1]; ps = [r['pstar'] for r in D1]
s = [r'\begin{tikzpicture}', r'\begin{groupplot}[group style={group size=2 by 1, horizontal sep=1.2cm}, width=4.4cm, height=4.3cm, ' + AX + ']',
     r'\nextgroupplot[xlabel={$\sqrt N$}, ylabel={depth $p^\ast$ for $P\ge0.9$}, xmin=0, xmax=17, ymin=0, legend style={at={(0.5,-0.32)}, anchor=north}]',
     rf'\addplot[only marks, mark=*, cBlue] coordinates {{{co(np.sqrt(Ns), ps)}}}; \addlegendentry{{one-hot QAOA, $D=1$}}',
     r'\addplot[black, densely dashed, domain=0:17] {pi/4*x}; \addlegendentry{$\tfrac\pi4\sqrt N$}',
     r'\node[anchor=north west, font=\scriptsize] at (rel axis cs:0.03,0.97) {(a)};',
     r'\nextgroupplot[xlabel={depth $p$}, ylabel={$P(\text{target})$}, xmin=0, xmax=40, ymin=0, ymax=1.05, legend columns=1, legend style={at={(0.5,-0.32)}, anchor=north}]']
for k, sty, lab in (('D2', 'cBlue, thick', r'$D=2$, product XY'), ('D3', 'cGreen, thick', r'$D=3$, product XY')):
    g = Q[k]['grover_xy_complete'][:40]; s.append(rf'\addplot[{sty}] coordinates {{{co(range(1, len(g) + 1), g)}}}; \addlegendentry{{{lab}}}')
for k, sty, lab in (('D2', 'cBlue, densely dotted', r'$D=2$, exact reflection'), ('D3', 'cGreen, densely dotted', r'$D=3$, exact reflection')):
    g = Q[k]['global_grover'][:40]; s.append(rf'\addplot[{sty}] coordinates {{{co(range(1, len(g) + 1), g)}}}; \addlegendentry{{{lab}}}')
g = Q['D3']['grover_xy_ring'][:40]; s.append(rf'\addplot[cGray, thick] coordinates {{{co(range(1, len(g) + 1), g)}}}; \addlegendentry{{$D=3$, ring XY}}')
s += [r'\node[anchor=south east, font=\scriptsize] at (rel axis cs:0.97,0.03) {(b)};', r'\end{groupplot}', r'\end{tikzpicture}']
W('fig_grover.tex', '\n'.join(s))
# ---------------- Fig 5: ablations (D=1, N=8), raw and softmax costs, three mixers
Xr = J('xmixer_raw.json'); Xs = J('xmixer.json')
s = [r'\begin{tikzpicture}', r'\begin{groupplot}[group style={group size=2 by 1, horizontal sep=0.35cm, y descriptions at=edge left}, width=4.75cm, height=4.4cm, ybar=0.6pt, /pgf/bar width=2.6pt, xlabel={depth $p$}, ymin=0, ymax=1.25, ytick={0,0.5,1}, xtick={1,2,3,4}, enlarge x limits=0.2, ylabel={$P(\text{target})$}, ' + AX + ']']
for X, lab in ((Xr, '(a) raw cost'), (Xs, '(b) softmax cost')):
    leg = X is Xs
    s.append(r'\nextgroupplot' + (r'[legend columns=3, legend style={at={(-0.02,1.04)}, anchor=south, /tikz/every even column/.append style={column sep=5pt}}]' if leg else ''))
    for key, sty, name in (('xy_complete', 'fill=cBlue, draw=cBlue', 'complete XY'), ('xy_ring', 'fill=cGreen, draw=cGreen', 'ring XY'), ('X', 'fill=cOrange, draw=cOrange', 'X mixer + penalty')):
        s.append(rf'\addplot[{sty}] coordinates {{{co([1, 2, 3, 4], [X[f"{key}_p{p}"]["P"] for p in (1, 2, 3, 4)])}}};' + (rf' \addlegendentry{{{name}}}' if leg else ''))
    s.append(rf'\node[anchor=north west, font=\scriptsize] at (rel axis cs:0.03,0.97) {{{lab}}};')
s += [r'\end{groupplot}', r'\end{tikzpicture}']
W('fig_ablation.tex', '\n'.join(s))
# ---------------- Fig 6: unequal masses
import blq_core as BQ
s = [r'\begin{tikzpicture}', r'\begin{groupplot}[group style={group size=2 by 1, horizontal sep=1.1cm}, ' + AX + ']',
     r'\nextgroupplot[width=4.6cm, height=4.6cm, xlabel={mass ratio $q$}, ylabel={$A_{\rm in}/A_{\rm out}-1$ ($10^{-3}$)}, xmin=0.74, xmax=1.01, ymin=0, ymax=7, legend style={at={(0.5,1.03)}, anchor=south}, legend columns=2]']
for dM, sty in ((0.73, 'cOrange, thick, mark=*, mark size=1.5pt'), (0.75, 'cBlue, thick, mark=square*, mark size=1.5pt')):
    R = J(f'blq_cont_dM{dM}.json')['rows']; m0 = M['%g' % (2 * dM)]
    qs = [1.0] + [r['q'] for r in R]; ys = [1e3 * (m0['A_in'] / m0['A_out'] - 1)] + [1e3 * (r['A_in'] / r['A_out'] - 1) for r in R]
    s.append(rf'\addplot[{sty}] coordinates {{{co(qs, ys)}}}; \addlegendentry{{$d/M={dM}$}}')
s.append(r'\node[anchor=south west, font=\scriptsize] at (rel axis cs:0.03,0.03) {(a)};')
R = J('blq_cont_dM0.75.json')['rows']; r8 = min(R, key=lambda r: abs(r['q'] - 0.8)); q8 = r8['q']; BQ.set_q(q8); BQ.NM = 120
th = np.linspace(1e-4, np.pi - 1e-4, 181)
s.append(r'\nextgroupplot[width=3.9cm, height=5.4cm, axis equal image, xmin=-0.95, xmax=0.95, ymin=-1.45, ymax=1.45, xlabel={$x$}, ylabel={$z$}]')
for key, sty in (('c_out', 'cBlue, thick'), ('c_in', 'cOrange, thick, dashed')):
    h = BQ.shape(np.array(r8[key]), th)[0]; x, z = h * np.sin(th), h * np.cos(th)
    s.append(rf'\addplot[{sty}] coordinates {{{co(np.concatenate([x, -x[::-1]]), np.concatenate([z, z[::-1]]), "%.4f")}}};')
z1, z2 = BQ.zc[0] * r8['d'], BQ.zc[1] * r8['d']
s.append(rf'\addplot[only marks, mark=x, mark size=2.4pt, black] coordinates {{(0,{z1:.4f})}};')
s.append(rf'\addplot[only marks, mark=x, mark size=1.6pt, black] coordinates {{(0,{z2:.4f})}};')
s.append(rf'\node[anchor=north west, font=\scriptsize] at (rel axis cs:0.03,0.98) {{(b) $q={q8:.2f}$}};')
s += [r'\end{groupplot}', r'\end{tikzpicture}']
W('fig_unequal.tex', '\n'.join(s))
print('q8', q8, r8['d'], r8['A_in'] / r8['A_out'] - 1, r8['V_in'], r8['V_out'])

# ---------------- Fig 7: block diagram of the coherent cost oracle (stage costs of Table 9)
cnt = J('oracle_count.json')['per_node']; K = J('oracle_count.json')['K']
# stage: (label, mul, cmul, add, recip, rsqrt, sqrt) -- the inventory of Appendix B, Table 9
ST = [(r'$h,h^\prime,h^{\prime\prime}$ from $c_\ell$', 0, 3 * K + 3, 3 * K - 2, 0, 0, 0),
      (r'Cartesian $x,z$', 0, 2, 0, 0, 0, 0),
      (r'$\psi$, $\nabla\psi$ (2 punctures)', 12, 4, 10, 0, 2, 0),
      (r'radial/polar projection', 0, 4, 2, 0, 0, 0),
      (r'$H_\delta$ and normal $\nu$', 13, 5, 5, 3, 0, 1),
      (r'$\theta_{(\ell)}$', 5, 1, 2, 1, 0, 0),
      (r'$dA$, $\theta_{(\ell)}^2dA$, $h^3$', 7, 0, 0, 0, 0, 0),
      (r'accumulate $\Theta$, $V$', 0, 2, 2, 0, 0, 0)]
tot = [sum(st[i] for st in ST) for i in range(1, 7)]
assert tot == [cnt['mul'], cnt['cmul'], cnt['add'], cnt['recip'], cnt['rsqrt'], cnt['sqrt']], tot
def cost(st): b2 = st[1] + st[2] + 6 * st[4] + 9 * st[5] + 10 * st[6]; b1 = 2 * st[3]; return b2, b1
def fmt(b2, b1): return (f'${b2}\\,b^2' + (f'+{b1}\\,b' if b1 else '') + '$') if b2 else (f'${b1}\\,b$' if b1 else '0')
s = [r'\begin{tikzpicture}[font=\scriptsize, node distance=1.5mm,',
     r' blk/.style={draw, rounded corners=1pt, minimum width=3.3cm, minimum height=4.2mm, align=center, fill=cBlue!8},',
     r' io/.style={draw, rounded corners=1pt, minimum width=3.3cm, minimum height=4.2mm, align=center, fill=cGray!15},',
     r' cst/.style={anchor=west, font=\scriptsize}]',
     r'\node[io] (in) {one-hot register, $DN$ qubits};',
     r'\node[io, below=of in] (ld) {load $c_\ell$: CNOTs, no Toffoli};']
prev = 'ld'
for k, st in enumerate(ST):
    s.append(rf'\node[blk, below=of {prev}] (s{k}) {{{st[0]}}};')
    s.append(rf'\node[cst] at ([xshift=2mm]s{k}.east) {{{fmt(*cost(st))}}};')
    prev = f's{k}'
b2, b1 = sum(cost(st)[0] for st in ST), sum(cost(st)[1] for st in ST)
s += [rf'\node[io, below=3mm of {prev}] (cmp) {{$\Cc_\lambda=-V+\lambda\Theta$, compare with $\Cc_y$}};',
      r'\node[io, below=of cmp] (ph) {phase $(-1)^{[\Cc<\Cc_y]}$, then uncompute};']
s += [r'\draw[-{Stealth[length=1.4mm]}] (in) -- (ld);', r'\draw[-{Stealth[length=1.4mm]}] (ld) -- (s0);']
s += [rf'\draw[-{{Stealth[length=1.4mm]}}] (s{k}) -- (s{k+1});' for k in range(len(ST) - 1)]
s += [rf'\draw[-{{Stealth[length=1.4mm]}}] (s{len(ST)-1}) -- (cmp);', r'\draw[-{Stealth[length=1.4mm]}] (cmp) -- (ph);',
      rf'\draw[decorate, decoration={{brace, amplitude=3pt, mirror}}, thick] ([xshift=-2mm]s0.north west) -- ([xshift=-2mm]s{len(ST)-1}.south west)'
      rf' node[midway, left=4pt, align=right] {{per node\\ ${b2}\,b^2+{b1}\,b$\\[2pt] $\times\,Q$ nodes\\ $\times\,2$ (uncompute)}};',
      r'\end{tikzpicture}']
W('fig_oracle.tex', '\n'.join(s))
