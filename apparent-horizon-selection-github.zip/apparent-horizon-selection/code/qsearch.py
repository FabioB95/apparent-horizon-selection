"""Exact simulation of one-hot QAOA in the feasible subspace (product of D single-excitation sectors)."""
import numpy as np
from scipy.linalg import expm
from scipy.optimize import minimize
def mixer_block(N, kind):
    if kind == 'xy_complete': return 2 * (np.ones((N, N)) - np.eye(N))
    if kind == 'xy_ring':
        M = np.zeros((N, N))
        for k in range(N): M[k, (k + 1) % N] = M[(k + 1) % N, k] = 2
        return M
    raise ValueError(kind)
class OneHot:
    def __init__(self, cost, kind='xy_complete'):
        self.kind = kind; self.c = np.asarray(cost, float); self.shape = self.c.shape; self.D = self.c.ndim
        self.M = [mixer_block(n, kind) for n in self.shape]
        self.ev = [np.linalg.eigh(m) for m in self.M]
        self.psi0 = np.ones(self.shape, complex) / np.sqrt(self.c.size)
    def mix(self, psi, beta):
        for b, (w, U) in enumerate(self.ev):
            n = self.shape[b]
            if self.kind == 'xy_complete':   # exp(-i beta 2(J-I)) = e^{2i beta}[I + (e^{-2i beta n}-1)|W><W|]
                m = psi.mean(axis=b, keepdims=True)
                psi = np.exp(2j * beta) * (psi + (np.exp(-2j * beta * n) - 1) * m)
            else:
                Ub = (U * np.exp(-1j * beta * w)) @ U.T
                psi = np.moveaxis(np.tensordot(Ub, np.moveaxis(psi, b, 0), axes=1), 0, b)
        return psi
    def state(self, gammas, betas, phase):
        psi = self.psi0.copy()
        for g, b in zip(gammas, betas): psi = self.mix(np.exp(-1j * g * phase) * psi, b)
        return psi
def optimize(model, phase, p, target, starts=20, seed=0, metric='energy'):
    rng = np.random.default_rng(seed); best = None
    def f(x):
        psi = model.state(x[:p], x[p:], phase); pr = np.abs(psi) ** 2
        return float(np.sum(pr * phase)) if metric == 'energy' else -float(pr.flat[target])
    for s in range(starts):
        x0 = np.concatenate([rng.uniform(0, 2 * np.pi, p), rng.uniform(0, np.pi, p)])
        r = minimize(f, x0, method='L-BFGS-B')
        psi = model.state(r.x[:p], r.x[p:], phase); P = float(np.abs(psi.flat[target]) ** 2)
        if best is None or r.fun < best[0]: best = (r.fun, P, r.x)
    return best
def grover_like(model, target, pmax, nb=400):
    """phase oracle (pi on target), one free mixer angle beta optimized per depth; returns best success per p"""
    phase = np.zeros(model.shape); phase.flat[target] = np.pi; out = []
    betas = np.linspace(0, np.pi / 2, nb)
    for p in range(1, pmax + 1):
        best = 0
        for b in betas:
            psi = model.state([1.0] * p, [b] * p, phase); best = max(best, float(np.abs(psi.flat[target]) ** 2))
        out.append(best)
    return out
def global_grover(n_states, pmax):
    th = np.arcsin(1 / np.sqrt(n_states)); return [float(np.sin((2 * p + 1) * th) ** 2) for p in range(1, pmax + 1)]
def true_grover(model, target, pmax):
    """amplitude amplification with the exact reflection 2|W^D><W^D| - I about the initial state,
    implemented in the one-hot register as W-prep^dag (2|0><0|-I) W-prep; simulated directly in the feasible subspace"""
    psi0 = model.psi0; psi = psi0.copy(); out = []
    for p in range(pmax):
        psi = psi.copy(); psi.flat[target] *= -1                         # phase oracle
        psi = 2 * psi0 * np.vdot(psi0, psi) - psi                         # reflection about the initial state
        out.append(float(np.abs(psi.flat[target]) ** 2))
    return out
